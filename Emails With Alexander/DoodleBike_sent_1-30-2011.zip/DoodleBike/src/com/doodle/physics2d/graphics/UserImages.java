
package com.doodle.physics2d.graphics;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import at.emini.physics2D.Body;
import at.emini.physics2D.UserData;

import com.doodle.physics2d.full.bike.R;
import com.doodle.physics2d.full.bike.R.drawable;

public class UserImages implements UserData {



    public static final String[] Identifiers = {"killBody","body","wheel"}; // ,"mario1","mario2","mario3","mario4","mario5","mario7","mario8","mario9","mario10","mario11","mario12","mario13","mario14","mario15","mario16","mario17","mario18","mario19","mario20" };
 //  };

    	public static int[] BitmapIds = 
    {    		
    		R.drawable.testline,
    		R.drawable.body,
			R.drawable.wheel,
		
    	//	0,0, // Body and wheel
    		
    	/*	0,0,0,0,0,   // 3 - 7
    		0,0,0,0,0,   // 8 - 12
    		0,0,0,0,0,   
    		0,0,0,0,0,
    		*/
    		
        
      /* 
        R.drawable.mario1,
        R.drawable.mario2,
        R.drawable.mario3,       
        R.drawable.mario4,
        R.drawable.mario5,
           
        
        R.drawable.mario7,
        R.drawable.mario8,
        R.drawable.mario9, 
        
        R.drawable.mario10,
        R.drawable.mario11,
        R.drawable.mario12,
        
        R.drawable.mario13,
        R.drawable.mario14, 
        
        R.drawable.mario15,
        R.drawable.mario16,
        
        R.drawable.mario17,
        R.drawable.mario18, 
        
        R.drawable.mario19,
        R.drawable.mario20,
        
        */
        
     /*   R.drawable.eraser,
        R.drawable.crayon,
        R.drawable.pencil,
        R.drawable.ruler,
        R.drawable.button,   */
    };  
    
    public static Bitmap[] bitmaps = new Bitmap[BitmapIds.length];
  //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      public int type = -1;
	
    public static int  M_TYPE_ONKILL = 0;
      public static int M_TYPE_BIKE = 1; 
      public static int M_TYPE_WHEEL = 2; 
    
    
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	public UserImages()
	{
	}
	 
	
	private UserImages(int type)
	{
		this.type = type;
	}
	
	public int type()
	{
	    return type;	    
	}
	
	public Bitmap getImage()
	{
	    return bitmaps[type];
	}
	
	public static void initBitmaps(Resources res)
	{
	    for( int i = 0; i < BitmapIds.length; i++)
	    {
	        bitmaps[i] = BitmapFactory.decodeResource(res, BitmapIds[i]);
	    }
	}

	
	
	
//	@Override
	public UserData copy() {
		return new UserImages(type);
	}

//	@Override
	public UserData createNewUserData(String data, int type)
	{
		
		for( int i = 0; i < Identifiers.length; i++)
		{
		    if (data.equals(Identifiers[i]))
		    {
		        return new UserImages(i);
		    }
		}
		
		return null;
	}

}
