// Author Brian A. Purgert
// Physics by Alexander Adensamer

package com.doodle.physics2d.graphics;

import java.util.Random;

import com.doodle.physics2d.full.bike.DoodleBikeMain;

import com.doodle.physics2d.full.bike.R;
import android.view.View;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Shader.TileMode;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LightingColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Shader.TileMode;
import android.hardware.SensorListener;
import android.hardware.SensorManager;
import android.view.View;
import android.widget.RelativeLayout;
import at.emini.physics2D.Body;
import at.emini.physics2D.Constraint;
import at.emini.physics2D.Event;
import at.emini.physics2D.Landscape;
import at.emini.physics2D.Motor;
import at.emini.physics2D.ParticleEmitter;
import at.emini.physics2D.Shape;
import at.emini.physics2D.Spring;
import at.emini.physics2D.UserData;
import at.emini.physics2D.World;
import at.emini.physics2D.util.FXUtil;
import at.emini.physics2D.util.FXVector;

public class GraphicsWorld extends World implements SensorListener
{
	public static boolean frontwheel; // Variable to load the motor for the front wheel
	DoodleBikeMain game;
	private boolean drawLandscape = false;

    private Body bodyToRemove = null;
    
	//helper points for spring drawing
    private FXVector p1 = new FXVector();
    private FXVector p2 = new FXVector();

    

  //--------------Turning Body--------------//
 private int mBikeMotorForceFX = -415 * FXUtil.ONE_FX;   
 private final long mBikeSpeedFactorFX = -5000 * FXUtil.ONE_FX;
    public  Motor mBikeMotor;  
    public   Event crash;
    public  static  Body crashBody;
   
    
    private final int baseGravityFX = 130 * FXUtil.ONE_FX;
  //  private FXVector newGravity = new FXVector(0, baseGravityFX);  
    //--------------wheels--------------//
   
    private final int mWheelMotorForceFX = 200000 * FXUtil.ONE_FX;
    private final long mWheelSpeedFactorFX = 10000 * FXUtil.ONE_FX;
    
    public static int landscapeWidth;
    public static int lColor1;
    public static int lColor2;
    public static int lColor3;
    
    private Motor mWheelMotor1;
    private Motor mWheelMotor2;
    
    
    public static final Paint renderBodies = new Paint();
    public static final Paint renderBodies2 = new Paint();
    public static final Paint renderStaticBodies = new Paint();
    public static final Paint renderSpring = new Paint();
    public static final Paint renderLandscape = new Paint();
    public static final Paint renderLandscapeback = new Paint();
    public static final Paint renderBackground = new Paint();
    
    public static final Paint renderParticles1 = new Paint();
    public static final Paint renderParticles2 = new Paint();
    public static final Paint renderParticles3 = new Paint();
    public static final Paint renderParticles4 = new Paint();
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    public static final Paint black1 = new Paint();
    public static final Paint black2 = new Paint();
    public static final Paint black3 = new Paint();
    public static final Paint black4 = new Paint();
    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    static 
    {
    	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    	black1.setStrokeWidth(10);     //13
    	black1.setStyle(Style.FILL_AND_STROKE);
    	black1.setStrokeJoin(Paint.Join.ROUND );  //bevel miter round
    	black1.setStrokeCap (Paint.Cap.ROUND);              // but round square
    	black1.setColor(Color.rgb(0,0,0)); 
    	black1.setAntiAlias(true);
    	
    	black2.setStrokeWidth(8);   //8  
    	black2.setStyle(Style.FILL_AND_STROKE);
    	black2.setStrokeJoin(Paint.Join.ROUND );  //bevel miter round
    	black2.setStrokeCap (Paint.Cap.ROUND);              // but round square 
    	black2.setColor(Color.rgb(160,160,160)); 
    	black2.setAntiAlias(true); 
   	
    	black3.setStrokeWidth(15);     
    	black3.setStyle(Style.FILL_AND_STROKE);
    	black3.setStrokeJoin(Paint.Join.ROUND );  //bevel miter round
    	black3.setStrokeCap (Paint.Cap.ROUND);              // but round square
    	black3.setColor(Color.rgb(0,0,0)); 
    	black3.setAntiAlias(true);
    	black3.setAlpha (40);
    	
    	black4.setStrokeWidth(2);     
    	black4.setStyle(Style.FILL_AND_STROKE);
    	black4.setStrokeJoin(Paint.Join.ROUND );  //bevel miter round
    	black4.setStrokeCap (Paint.Cap.ROUND);              // but round square
    	black4.setColor(Color.rgb(255,255,0)); 
    	black4.setAntiAlias(true);

       	renderBodies.setStrokeWidth(2);     //13
       	renderBodies.setStyle(Style.FILL_AND_STROKE);
       	renderBodies.setStrokeJoin(Paint.Join.ROUND );  //bevel miter round
       	renderBodies.setStrokeCap (Paint.Cap.ROUND);              // but round square
    	renderBodies.setAlpha (150); 
       	renderBodies.setColor(Color.rgb(0,0,0)); 
       	renderBodies.setAntiAlias(true);
    	
       	renderBodies2.setStrokeWidth(4);   //8  
       	renderBodies2.setStyle(Style.FILL_AND_STROKE);
       	renderBodies2.setStrokeJoin(Paint.Join.ROUND );  //bevel miter round
       	renderBodies2.setStrokeCap (Paint.Cap.ROUND);              // but round square 
       	renderBodies2.setColor(Color.rgb(0,0,0)); 
    	renderBodies2.setAlpha (190);
       	renderBodies2.setAntiAlias(true); 
    	//++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   
 
        renderStaticBodies.setAntiAlias(true);
        renderSpring.setColor(Color.rgb(255,140,0));    
        renderStaticBodies.setColor(Color.rgb(255,140,0)); 
        
        renderLandscape.setStrokeWidth(9);     
        renderLandscape.setStyle(Style.FILL_AND_STROKE);
        renderLandscape.setStrokeJoin(Paint.Join.ROUND );  //bevel miter round
        renderLandscape.setStrokeCap (Paint.Cap.ROUND);              // but round square
        renderLandscape.setAlpha (180); 
        
        renderLandscapeback.setStrokeWidth(15);     
        renderLandscapeback.setStyle(Style.FILL_AND_STROKE);
        renderLandscapeback.setStrokeJoin(Paint.Join.ROUND );  //bevel miter round
        renderLandscapeback.setStrokeCap (Paint.Cap.ROUND);              // but round square
        renderLandscapeback.setAlpha (160); 
        renderStaticBodies.setStyle(Style.FILL); 
    
        renderParticles1.setColor(Color.rgb(5,8,128));  
        renderParticles2.setColor(Color.rgb(255,53,45)); 
        renderParticles3.setColor(Color.rgb(255,255,255)); 
        renderParticles4.setColor(Color.rgb(0,221,0)); 
    }
    


    public GraphicsWorld()
    {
        super();
    }
    
    public GraphicsWorld(int baseGravityFX)
    {
        super();
    //    this.baseGravityFX = baseGravityFX;
    }

    public GraphicsWorld(World world)
    {        
        super(world);
     
    }
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
    //                    Initiate Motors                        //
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
    public void initMotors()
    {
        int bodyCount = getBodyCount();
        Body[] bodies = getBodies();
        crashBody = bodies[2];
        for( int i = 0; i < bodyCount; i++)         
        {
            UserImages userShapedata = (UserImages) (bodies[i].shape().getUserData());
            if(userShapedata == null) continue;          
             if ( userShapedata.type == UserImages.M_TYPE_BIKE )
            {                    
                mBikeMotor = new Motor(bodies[i], 0, mBikeMotorForceFX);
                addConstraint(mBikeMotor);
                mBikeMotor.setParameter(0, 0, true, false);        
                
            }
            else if ( userShapedata.type == UserImages.M_TYPE_WHEEL )
            {       
                Motor wheelMotor = new Motor(bodies[i], 0, mWheelMotorForceFX);
                
                if (mWheelMotor1 == null) 
                {
                    mWheelMotor1 = wheelMotor;
                }
                else if (mWheelMotor2 == null)
                {
                    mWheelMotor2 = wheelMotor;
                }
            }
            
        }
        
             
    }
    

    public void translate(FXVector translation)
    {
        int bodyCount = getBodyCount();
        Body[] bodies = getBodies();
        for( int i = 0; i < bodyCount; i++)
        {
            bodies[i].positionFX().add( translation);
        }
    }

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++//   
//                     Render LandScape                    //  
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
    public void draw(Canvas canvas, int xTranslate, int yTranslate)
    {           
        canvas.translate(-xTranslate, -yTranslate);
        
        if ( drawLandscape)
        {
            Landscape landscape = getLandscape();
            FXVector startPoint, endPoint;
            for( int i = 0; i < landscape.segmentCount(); i++)
            {        
                startPoint = landscape.startPoint(i);
                endPoint = landscape.endPoint(i);
            
                
                canvas.drawLine(startPoint.xFX >> FXUtil.DECIMAL , 
                        startPoint.yFX >> FXUtil.DECIMAL ,
                        endPoint.xFX >> FXUtil.DECIMAL , 
                        endPoint.yFX >> FXUtil.DECIMAL ,
                        black3);   

            }
            for( int i = 0; i < landscape.segmentCount(); i++)
            {        
                startPoint = landscape.startPoint(i);
                endPoint = landscape.endPoint(i);
   
                
                canvas.drawLine(startPoint.xFX >> FXUtil.DECIMAL, 
                startPoint.yFX >> FXUtil.DECIMAL,
                endPoint.xFX >> FXUtil.DECIMAL, 
                endPoint.yFX >> FXUtil.DECIMAL,
                black1);
                

              
            }
            for( int i = 0; i < landscape.segmentCount(); i++)
            {        
                startPoint = landscape.startPoint(i);
                endPoint = landscape.endPoint(i);

                canvas.drawLine(startPoint.xFX >> FXUtil.DECIMAL, 
                        startPoint.yFX >> FXUtil.DECIMAL,
                        endPoint.xFX >> FXUtil.DECIMAL, 
                        endPoint.yFX >> FXUtil.DECIMAL,
                        black2);
                

              
            }
            
            for( int i = 0; i < landscape.segmentCount(); i++)
            {        
                startPoint = landscape.startPoint(i);
                endPoint = landscape.endPoint(i);
           
                canvas.drawLine(startPoint.xFX >> FXUtil.DECIMAL, 
                        startPoint.yFX >> FXUtil.DECIMAL,
                        endPoint.xFX >> FXUtil.DECIMAL, 
                        endPoint.yFX >> FXUtil.DECIMAL,
                        black4);

    
            }
            
        }
        
//+++++++++++++++++++++++++++++++++++++++++++++++++//
//                  Render Springs                  //        
//+++++++++++++++++++++++++++++++++++++++++++++++++//        
        int constraintCount = getConstraintCount();
        Constraint[] constraints = getConstraints();
        
        for(int i = 0; i < constraintCount; i++)
        {    
            if (constraints[i] instanceof Spring)
            {
                Spring spring = (Spring) constraints[i];
                spring.getPoint1(p1);
                spring.getPoint2(p2);
                canvas.drawLine(p1.xFX >> FXUtil.DECIMAL, p1.yFX >> FXUtil.DECIMAL, 
                                p2.xFX >> FXUtil.DECIMAL, p2.yFX >> FXUtil.DECIMAL, 
                                renderSpring);                
            }
        }
   
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
//                   Render particles                           //
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
        for( int i = 0; i < getParticleEmitters().size(); i++)
        {            
            ParticleEmitter emitter = (ParticleEmitter) getParticleEmitters().elementAt(i);
            
            int[] xFX = emitter.getXPosFX();
            int[] yFX = emitter.getYPosFX();
            short[] life = emitter.getLifeTimes();
            int size = xFX.length; 
            int particle = 1;
            for( int j = 0; j < size; j++)
            {
                if (life[j] > 0)
                {      
                	particle++;
           //       canvas.drawCircle(xFX[j]>>FXUtil.DECIMAL, yFX[j]>>FXUtil.DECIMAL, 1, renderParticles3);
            	//    canvas.drawBitmap(SimulationView.particle1, xFX[j]>>FXUtil.DECIMAL, yFX[j]>>FXUtil.DECIMAL, null);
            //      canvas.drawBitmap(R.drawable.back, xFX[j]>>FXUtil.DECIMAL, yFX[j]>>FXUtil.DECIMAL, renderParticles); 

            //    	switch (particle) {
	         //        case 1:  canvas.drawCircle(xFX[j]>>FXUtil.DECIMAL, yFX[j]>>FXUtil.DECIMAL, 1, renderParticles1);   break;
	        //         case 2: canvas.drawCircle(xFX[j]>>FXUtil.DECIMAL, yFX[j]>>FXUtil.DECIMAL, 2, renderParticles2);   break;
	        //         case 3: canvas.drawCircle(xFX[j]>>FXUtil.DECIMAL, yFX[j]>>FXUtil.DECIMAL, 1, renderParticles3);  break;
	        //         case 4: canvas.drawCircle(xFX[j]>>FXUtil.DECIMAL, yFX[j]>>FXUtil.DECIMAL, 2, renderParticles4);  
	        //        	 particle = 1;   break;              
	        //      }  	 
                	
                   
                }
            }            
        }
        
        /*
         * Draw the bodies
         * by walking over all bodies that are currently in
         * simulation scope (see World#setSimulationArea())
         * so we walk from getBodyStartIndex() to getBodyEndIndex()
         */        
        Body[] bodies = getBodies();
        int bodyEndIndex = getBodyEndIndex();        
        for(int i = getBodyStartIndex(); i < bodyEndIndex; i++)
        {   
        	drawBody( canvas, bodies[i], xTranslate, yTranslate);
        }
        
        canvas.translate(xTranslate, yTranslate);
    }
   //+++++++++++++++++++++++++++++++++++++++++++++++++++++//
   //                   Render Bodies                     //
   //+++++++++++++++++++++++++++++++++++++++++++++++++++++//
    private Matrix matrix = new Matrix();    
    public final void drawBody(Canvas canvas, Body body, int xTranslate, int yTranslate)
    {   
     //   if ( body.getAABBMinXFX() > (canvas.getWidth() + xTranslate ) * FXUtil.ONE_FX || 
    	 if ( body.getAABBMinXFX() > (820 + xTranslate ) * FXUtil.ONE_FX || 
             body.getAABBMaxXFX() < xTranslate * FXUtil.ONE_FX ||
             body.getAABBMinYFX() > (480 + yTranslate ) * FXUtil.ONE_FX || 
         //    body.getAABBMinYFX() > (canvas.getHeight() + yTranslate ) * FXUtil.ONE_FX || 
             body.getAABBMaxYFX() < yTranslate * FXUtil.ONE_FX )
        {
            return;
        }
        
        
        Shape shape = body.shape();      
     //   Bitmap image = ((GraphicsShapeSet) shapeSet).getImage(shape);  //check if an image is registered for the body
        Bitmap image = null;
        
        UserData userdata = shape.getUserData();
        if (userdata != null && userdata instanceof UserImages)
        {
            image = ((UserImages) userdata).getImage();
        }
        
        if (image != null)
        { 
            //draw the image if one was found
            FXVector position = body.positionFX();
            matrix.reset();
            matrix.postRotate( ((float) body.rotation2FX() * 360f / FXUtil.TWO_PI_2FX),
                    image.getWidth() / 2, image.getHeight() / 2);
            matrix.postTranslate(
                    (position.xFX >> FXUtil.DECIMAL) - image.getWidth() / 2,
                    (position.yFX >> FXUtil.DECIMAL) - image.getHeight() / 2);
            Paint paint = renderBodies;
            if(! body.isDynamic())
            {
                paint = renderStaticBodies;
            }
            canvas.drawBitmap(image, matrix, paint);
        }
        else
        {
            FXVector[] positions = body.getVertices();
            if (positions.length == 1)
            {
                canvas.drawCircle(
                        body.positionFX().xFX >> FXUtil.DECIMAL, 
                        body.positionFX().yFX >> FXUtil.DECIMAL, 
                        body.shape().getBoundingRadiusFX() >> FXUtil.DECIMAL, 
                        renderBodies);
            }
            else
            {
                for( int j = positions.length - 1, i = 0; i < positions.length; j = i,i++)
                {           
                    canvas.drawLine(
                            positions[i].xFX >> FXUtil.DECIMAL, 
                            positions[i].yFX >> FXUtil.DECIMAL, 
                            positions[j].xFX >> FXUtil.DECIMAL, 
                            positions[j].yFX >> FXUtil.DECIMAL, 
                            renderBodies);
                    canvas.drawLine(
                            positions[i].xFX >> FXUtil.DECIMAL, 
                            positions[i].yFX >> FXUtil.DECIMAL, 
                            positions[j].xFX >> FXUtil.DECIMAL, 
                            positions[j].yFX >> FXUtil.DECIMAL, 
                            renderBodies);
                }   
               
            }
        }
    }
   
    public void tick()
    {
  //      setGravity(newGravity);
    	
        super.tick();
        
        if (bodyToRemove != null)
        {
            removeBody(bodyToRemove);    
            bodyToRemove = null;
        }
    }
      
    
    public boolean isDrawLandscape()
    {
        return drawLandscape;
    }

    public void setDrawLandscape(boolean drawLandscape)
    {
        this.drawLandscape = drawLandscape;
    }
  
    public void setNewGravity(int newGravityX, int newGravityY)
    {      
    	FXVector gravityRaw = new FXVector( newGravityX,newGravityY);
    	gravityRaw.normalize();
    	
    	gravityRaw.multFX(baseGravityFX);
    	setGravity(gravityRaw );   
    	
    }
    
    public void onAccuracyChanged(int sensor, int accuracy)
    {        
    }
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
  //               Add Bike and create the motor attached to it                  //
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//  
   

    //++++++++++++++++++++++++++++++++++++++++++++++++++++
    float xvalue;
	float yvalue;
	float zvalue;
	public static int sensitivity;
	public static double biketiltingforce;
	public int max;
    public void onSensorChanged(int sensor, float[] values)
    {
    	
    xvalue = values[0]; 
    max = 12 - sensitivity;
   sensitivity = 8;
 
    switch(sensor) 
        {        
      case SensorManager.SENSOR_ACCELEROMETER:

    //-----Set The Maximum tilting force allowed-----//
    //---------and set the power of the tilt---------// 
    	  	   
     	   if (xvalue < max && xvalue > - max ){
     	        	    	setBikeTurningPower(xvalue);
     	        	    	setBikeTurningSpeed(xvalue);
     	    } 
     	    if (xvalue > max){
     	    	setBikeTurningPower(max);
     	    	setBikeTurningSpeed(max);
     	    }
     	    if (xvalue < -max){
     	    	setBikeTurningPower(-max);
     	    	setBikeTurningSpeed(-max);
     	    }
    	    
            break;
        default: 
            break;
        }
    }
    
    public final void setBikeTurningPower(float value)
    {   
        if (mBikeMotor != null)
        {
            int maxForceFX = (int) (value * mBikeMotorForceFX * biketiltingforce * sensitivity);
            
            mBikeMotor.setMaxForceFX(maxForceFX);
            
            
        }
    }

    public final void setBikeTurningSpeed(float value)
    {   
        if (mBikeMotor != null)
        {
            int targetAFX = (int) (value * mBikeSpeedFactorFX * biketiltingforce * sensitivity);
            mBikeMotor.setParameter(targetAFX, 0, true, false);
        }
    }

  //++++++++++++++++++++++++++++++++++++++++++++++++++++++++//  
      
    
    public final void setWheelSpeed(float value)
    {   
        if (mWheelMotor1 != null && mWheelMotor2 != null)
        {
           
            
            int targetAFX = -(int) (value * mWheelSpeedFactorFX);
            mWheelMotor1.setParameter(targetAFX, 0, true, false);
            mWheelMotor2.setParameter(targetAFX, 0, true, false);
           
        }
    }
   
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
//                       Wheel On/Off                        //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//    
    
    public final  void destroyBike(){
    	  int constraintCount = getConstraintCount();
          Constraint[] constraints = getConstraints();
          
          for(int i = constraintCount; i >= 0; i--)
          {     
                  removeConstraint(constraints[i]);          
          }                 
      putmotor();
      setWheelSpeed(10);
    }

    
    public final void putmotor(){
    	if(frontwheel == true){
    	addConstraint(mWheelMotor1);     // Front Wheel
    	}
    	addConstraint(mWheelMotor2);     // Rear Wheel
    	
    }
    public final void takemotor(){
    	removeConstraint(mWheelMotor1);    // Front Wheel
    	removeConstraint(mWheelMotor2);   // Rear Wheel
    }	
    	
    	
    }
    
    
    
    
    

