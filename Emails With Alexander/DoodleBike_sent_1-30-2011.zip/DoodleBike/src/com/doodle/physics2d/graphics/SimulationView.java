
package com.doodle.physics2d.graphics;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.BitmapDrawable;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnTouchListener;
import at.emini.physics2D.Motor;
import at.emini.physics2D.Body;
import at.emini.physics2D.util.FXUtil;





public class SimulationView extends SurfaceView implements SurfaceHolder.Callback, OnTouchListener 
{
    protected GraphicsWorld world;
 
    
    //Loading Level Variables
    
  //  private final float yy = getHeight()/480f;
 //   private final float xx = getWidth()/800f;
    
    
   public static  boolean forGroundBottom;
   public static  boolean forGroundTop;
    
    public static  float BGRateX; 
    public static float BGRateY;
    
    public static  float FGBRateX;
    public static float FGBRateY;
    
    public static float FGTRateX;
    public static float FGTRateY;
    
   public static int XViewPosition;
   public static int YViewPosition;
   public static double UpDownDelay;
   
   public static float BGX;
   public static float BGY;
   
   public static float FGBX;
   public static float FGBY;
   
   public static float FGTX;
   public static float FGTY;
    
    
    public static Bitmap particle1 = null;
    public static Bitmap particle2 = null;
    public static Bitmap particle3 = null;
    public static Bitmap particle4 = null;
    
    public static Bitmap landscapetexture = null;
    public static Bitmap landscapetexture2 = null;
    public static Bitmap landscapetextureback = null;
    
 //   DoodleBikeMain = main;
    
    public static Bitmap backGroundImage = null;
    private Bitmap forGroundBottomImage = null;
    private Bitmap forGroundTopImage = null;
    
    public Body viewBody = null;          //view centered around this body
    public Body killBody = null;
    private boolean useX = false;
    private boolean useY = false;
      
    public SimulationView(Context context, GraphicsWorld world) 
    {
        super(context);
        this.world = world;
        
        SurfaceHolder holder = getHolder();
        
        holder.addCallback(this);      
        setOnTouchListener(this);
    }
        
    public final void setBackground(Bitmap background)
    {
        backGroundImage = background;
    } 
    public final void setForgroundBottom(Bitmap forground)
    {
        forGroundBottomImage = forground;
    }  
    public final void setForgroundTop(Bitmap forground)
    {
        forGroundTopImage = forground;
    }
    
    
    public void setp1(Bitmap p1)
    {
        particle1 = p1;
    }  
    public void setp2(Bitmap p2)
    {
        particle2 = p2;
    }  
    public void setp3(Bitmap p3)
    {
        particle3 = p3;
    }  
    public void setp4(Bitmap p4)
    {
        particle4 = p4;
    }  
    
    public final void settexture(Bitmap bitmap)
    {
        landscapetexture = bitmap;
    }
    public final void settexture2(Bitmap bitmap)
    {
        landscapetexture2 = bitmap;
    }
    public final void settexture3(Bitmap bitmap)
    {
    	landscapetextureback = bitmap;
    }
    
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
    //                             View Center                                 //
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//  
    public void setViewCenter(Body viewBody) {  
    		this.viewBody = viewBody; 		
				}
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
    public void setViewBody(Body viewBody, boolean useX, boolean useY)
    {
        this.viewBody = viewBody;
        this.useX = useX;
        this.useY = useY;
    }
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//    
    public void setKillBody(Body killBody)
    {
        this.killBody = killBody;
    }      
    
    
    public final int getViewTranslateX()
    {
        return (int) ((useX && viewBody != null )? ((viewBody.positionFX().xFX >> FXUtil.DECIMAL)  - 800  /  XViewPosition ) : 0); //2 + 130 is default 
    }
    
    public final int getViewTranslateY()
    {
        return (int) ((useY && viewBody != null )? ((viewBody.positionFX().yFX >> FXUtil.DECIMAL)/UpDownDelay - 480 /  YViewPosition * 3 ) : 0); //time 3
    }
        
    public void resetWorld(GraphicsWorld world)
    {
        this.world = world;
    }
    
    
    
    public final void tickWorld()
    {
        if (world != null)
        {
            world.tick();
            Canvas c = null;
            SurfaceHolder holder = getHolder();
            try {
                c = holder.lockCanvas(null);
                synchronized (holder) {
                    doDraw(c);
                }
            } finally {

                if (c != null)             	
                    holder.unlockCanvasAndPost(c);
                }
            }
        }
    
  //  int xx = getHeight()/480;
 //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
 //                                 Canvas                                   //
 //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//  
    public   void doDraw(Canvas canvas) 
    {
    //	   canvas.setRotate (90);
    	if (world != null && canvas != null)
        {
    	//	bitmap1.setTileModeX(TileMode.REPEAT );
    		
    		
    		
    //        if (backGroundImage != null){  
         //   	canvas.scale(1, 1); 	
            //	canvas.setDensity ( DENSITY_LOW);
            //	setTo(DENSITY_LOW);
        //   int scaley =	getHeight()/480;  int scalex =	getWidth()/800;
            //	final Matrix mtx = new Matrix(); 
            //	mtx.preScale(sx, sy); 
            //	mtx.mapRect(rectF); 
           // 	canvas.drawRect(rectF, paint); 
          //  	canvas.restore(); 
      //      	System.out.println(canvas.getDensity());
      canvas.drawBitmap(backGroundImage,      (float) (getViewTranslateX()* -BGRateX ) + BGX ,(getViewTranslateY()* -BGRateY) + BGY,  null); 
      canvas.scale(-1, 1);
      canvas.drawBitmap(backGroundImage,      (float) -((getViewTranslateX()* -BGRateX ) + backGroundImage.getWidth()*2) ,(getViewTranslateY()* -BGRateY) + BGY,  null); 
      canvas.scale(-1, 1);
      canvas.drawBitmap(backGroundImage,      (float) (getViewTranslateX()* -BGRateX ) + backGroundImage.getWidth()*2 ,(getViewTranslateY()* -BGRateY) + BGY,  null); 
        //    	canvas.drawPaint (GraphicsWorld.renderBackground);
          //                         	}
            
      //     if(forGroundBottom == true && forGroundBottomImage != null){                     	                 	
   //   canvas.drawBitmap(GraphicsWorld.renderBodies, (float) (getViewTranslateX()* -FGBRateX),(getViewTranslateY()* -FGBRateY) + (getHeight()/3), null);            		
      //                            	}  
      
     
         
           
      //      if(forGroundBottom == true ){ 
//            float xx =	getViewTranslateX()* -FGBRateX;
//            float yy =	(getViewTranslateY()* -FGBRateY) + (getHeight()/3);
           //      canvas.drawRect(xx, yy, xx + getWidth() * 4,yy + getHeight(), null); 
        //         canvas.setimagedrawable(backGroundImage);
           //      setBounds (xx, yy, xx + getWidth() * 4,yy + getHeight());
     //       }
            
     //       BitmapDrawable  bitmap1 = new BitmapDrawable(background);	
    //        bitmap1.setTileModeX(TileMode.REPEAT );
     //            setBounds (getHeight(), 2000, getHeight(),2000);
            
            
            
    //       if(forGroundTop ==    true && forGroundTopImage    != null){
   //   canvas.drawBitmap(forGroundTopImage,    0,0, null);
     //   							}
           final float xx = getHeight()/480f;
         //  if(getHeight )
            canvas.scale(xx , xx); 
            world.draw(canvas, getViewTranslateX(), getViewTranslateY());               
           
        }
       
    }
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
//                                 Canvas                                   //
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++// 
//   private void(int)
    
    
    public  void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        if (width > 0 && height > 0)  {
            if (backGroundImage != null)
            {
         //       backGroundImage = Bitmap.createScaledBitmap( backGroundImage, getHeight() * 6,  getHeight(),       // new height
         //           true);
            }     
     //       if (forGroundBottomImage != null)
     //       {
       //     	forGroundBottomImage = Bitmap.createScaledBitmap(forGroundBottomImage, 2600,  getHeight(),       // new height
       //             true);
      //      }   
      //      if (forGroundTopImage != null)
     //       {
     //       	forGroundTopImage = Bitmap.createScaledBitmap(forGroundTopImage, getWidth(),  getHeight(),       // new height
     //               true);
      //      }   
        }    
    }

    
 
    
    public boolean onTouch(View v, MotionEvent event)
    {
        int x = (int) (event.getX() + getViewTranslateX());
        int y = (int) (event.getY() + getViewTranslateY());

        Body b = world.findBodyAt( x * FXUtil.ONE_FX, y * FXUtil.ONE_FX);
        if (b != null)  
       {
            return onTouchBody(b, event);
        }
        return false;
    }
   
    public boolean onTouchBody(Body body, MotionEvent event)
    {
        return false;
    }


    public void surfaceCreated(SurfaceHolder holder) 
    {       
    }

    public void surfaceDestroyed(SurfaceHolder holder) 
    {   
    }

	

	
}
