package com.doodle.physics2d.full.bike;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.Map;

import com.doodle.physics2d.full.bike.R;

import android.widget.ImageButton;

public class Menu extends Activity {
	
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle loadInstanceState) { 	  
        super.onCreate(loadInstanceState);

        setRequestedOrientation(0); 
        setContentView(R.layout.main);
        
        
        Typeface tf = Typeface.createFromAsset(getAssets(),
        "fonts/Brushed.ttf");
        
                     
   		
		
	        
        
        
        Button play   = (Button)findViewById(R.id.play);
        play.setTypeface(tf);
        
        Button info   = (Button) findViewById(R.id.info);
        info.setTypeface(tf);
        
      
 //       ImageButton option = (ImageButton) findViewById(R.id.options); 
  //      ImageButton instructions = (ImageButton) findViewById(R.id.instructions); 
       final Intent BikeIntent = new Intent(Menu.this,Level.class);

    
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
//                         Set up Menus                            //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//   
        play.setOnClickListener(new OnClickListener() {
        	public void onClick(View v) {
        		
        		
        		startActivity(BikeIntent);
        		
        		
        	}
        });                 
//--------------------------------------------------------//        
        
        info.setOnClickListener(new OnClickListener() {  	
        	public void onClick(View v) {
        		
        		 RelativeLayout message = (RelativeLayout) findViewById(R.id.RelativeLayout01);
        	       message.setVisibility(View.VISIBLE); 
        	 
        		
        	}
        });       
               
        TextView tv   = (TextView) findViewById(R.id.TextView01);
        tv.setTypeface(tf);
        
        Button close   = (Button) findViewById(R.id.close);
        	        close.setTypeface(tf);
        	        
        	        close.setOnClickListener(new OnClickListener() {
        	           	public void onClick(View v) {
        	           RelativeLayout message = (RelativeLayout) findViewById(R.id.RelativeLayout01);
        	           message.setVisibility(View.GONE); 
        	        	}
        	           });  
        	        /*
//--------------------------------------------------------//  
        instructions.setOnClickListener(new OnClickListener() {
        	public void onClick(View v) {
        		
        		Intent instructionsIntent = new Intent(Menu.this,Instructions.class);
        		startActivityForResult(instructionsIntent,0);
        		
        	}
        }); 
//--------------------------------------------------------//         
        option.setOnClickListener(new OnClickListener() {	
        	public void onClick(View v) {
        		
        		Intent OptionIntent = new Intent(Menu.this,Options.class);
        		startActivityForResult(OptionIntent,0);
        		
        	}
        });     */
//--------------------------------------------------------//            
    }
	/* @Override
    protected void onPause() 
    {
        super.onPause();
        
        SharedPreferences settings = getSharedPreferences("lvlsComplete", 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putInt("lvlsComplete", DoodleBikeMain.lvlsComplete);
        editor.commit();
        
    }  */
//--------------------// 
 //   @Override
 /*   protected void onResume() 
    {
        super.onResume();
        
        SharedPreferences settings = getSharedPreferences("count", 0);
        DoodleBikeMain.lvlsComplete = settings.getInt("count", DoodleBikeMain.lvlsComplete);

    }    */
}