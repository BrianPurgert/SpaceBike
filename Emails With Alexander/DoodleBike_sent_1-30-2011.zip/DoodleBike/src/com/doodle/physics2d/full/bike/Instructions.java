package com.doodle.physics2d.full.bike;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import at.emini.physics2D.Body;
import at.emini.physics2D.Motor;
import android.view.View.OnClickListener;

import com.doodle.physics2d.full.bike.DoodleBikeMain;
import com.doodle.physics2d.graphics.GraphicsWorld;
import com.doodle.physics2d.graphics.UserImages;
import com.doodle.physics2d.full.bike.R;

import android.content.Intent;
import android.graphics.Typeface;
import android.hardware.SensorManager;

public class Instructions extends Activity {
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);     
        
        setRequestedOrientation(0);
        setContentView(R.layout.instructions);
      
        Typeface tf = Typeface.createFromAsset(getAssets(),
        "fonts/Brushed.ttf");
        
        final Button next = (Button) findViewById(R.id.next);
        next.setTypeface(tf);
        final Button start = (Button) findViewById(R.id.start);
        start.setTypeface(tf);

    //    final ImageButton back = (ImageButton) findViewById(R.id.back);
        
    //    bike2.setBackgroundResource(locked1);
   //     bike3.setBackgroundResource(locked2);
        
        

        
		next.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) { 
				next.setVisibility(View.GONE);
				RelativeLayout background = (RelativeLayout) findViewById(R.id.RelativeLayout01);
				background.setVisibility(View.VISIBLE);
			} 
			
		});

        
		start.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) { 
				Intent PlayIntent = new Intent(Instructions.this,DoodleBikeMain.class);
				finish();
				 startActivity(PlayIntent);
			} 	
		});    
        
        
        
		
   }     
    
    protected void onResume() 
    {   	
        super.onResume();
    }  
    
}
		


