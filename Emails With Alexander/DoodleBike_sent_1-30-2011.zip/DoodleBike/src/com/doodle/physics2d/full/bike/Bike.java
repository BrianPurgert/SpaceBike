package com.doodle.physics2d.full.bike;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import at.emini.physics2D.Body;
import at.emini.physics2D.Motor;
import android.view.View.OnClickListener;

import com.doodle.physics2d.full.bike.DoodleBikeMain;
import com.doodle.physics2d.graphics.GraphicsWorld;
import com.doodle.physics2d.graphics.UserImages;
import com.doodle.physics2d.full.bike.R;

import android.content.Intent;
import android.graphics.Typeface;
import android.hardware.SensorManager;

public class Bike extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
     
    //    GraphicsWorld.biketiltingforce = 1; 
        
        setRequestedOrientation(0);
        setContentView(R.layout.bike);
       
        System.out.println("check3");
        
        final Typeface tf = Typeface.createFromAsset(getAssets(),
        "fonts/Brushed.ttf");
        final Button start = (Button) findViewById(R.id.start);
          start.setTypeface(tf);
  //      final ImageButton bike1 = (ImageButton) findViewById(R.id.bike1);
  //      final ImageButton bike2 = (ImageButton) findViewById(R.id.bike2);
  //      final ImageButton bike3 = (ImageButton) findViewById(R.id.bike3);
    //    final ImageButton bike4 = (ImageButton) findViewById(R.id.bike4);
        final ImageButton back = (ImageButton) findViewById(R.id.back);
        
    //    bike2.setBackgroundResource(locked1);
   //     bike3.setBackgroundResource(locked2);
        
        
    //    bike1.setVisibility(bv1);
    //    bike2.setVisibility(bv2);
    //    bike3.setVisibility(bv3);
        System.out.println("check1");
        
		start.setOnClickListener(new View.OnClickListener() {
			public final void onClick(View v) { 
				DoodleBikeMain.pickedBike = R.raw.chalkbike; 
				DoodleBikeMain.WheelSpeed = 8; //20 
				GraphicsWorld.biketiltingforce = .5; // 1.5		
				GraphicsWorld.frontwheel = true;
				
				finish();
				Intent levelIntent = new Intent(Bike.this,DoodleBikeMain.class); 
				
        		startActivity(levelIntent);
			} 
			
		});
	/*			
			bike2.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) { 
					DoodleBikeMain.pickedBike = R.raw.bike;
					DoodleBikeMain.WheelSpeed = 9; //9
					GraphicsWorld.biketiltingforce = 1.1;
					
//					 UserImages.BitmapIds[1] = R.drawable.motobike;
//					 UserImages.BitmapIds[2] = R.drawable.motowheel;
			//		 UserImages.BitmapIds[3] = R.drawable.motowheeld;
					
				//	UserImages.M_TYPE_BIKE = 1; 
				//	UserImages.M_TYPE_WHEEL = 2;
							
					
					
					
				
					
					GraphicsWorld.frontwheel = false;
					
					Intent levelIntent = new Intent(Bike.this,DoodleBikeMain.class);
					startActivityForResult(levelIntent,0); 
				
				}
				
			}); 
							
			bike3.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) { 
					DoodleBikeMain.pickedBike = R.raw.quad; 
					DoodleBikeMain.WheelSpeed = 8;
					
					UserImages.M_TYPE_BIKE = 1; 
					UserImages.M_TYPE_WHEEL = 2;
					

					
					GraphicsWorld.frontwheel = true;
				//	finish();
					Intent levelIntent = new Intent(Bike.this,DoodleBikeMain.class);
					startActivityForResult(levelIntent,0);
				}
			}); 
			
			/*
			bike4.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) { 
					PhysEngineAndroidSample.pickedBike = R.raw.flip;
					PhysEngineAndroidSample.WheelSpeed = 10;
					UserImages.M_TYPE_BIKE = 6; 
					UserImages.M_TYPE_WHEEL = 7;
					GraphicsWorld.frontwheel = true;
					Intent levelIntent = new Intent(Bike.this,Level.class);
	        		startActivityForResult(levelIntent,0);
				}
			});
        */
        
		back.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) { 
			//	Intent MenuIntent = new Intent(Bike.this,Level.class);
        	//	startActivityForResult(MenuIntent,0);
				finish();
			} 	
		});    
        
        
        
		
   }     
    
    protected void onResume() 
    {   	
        super.onResume();

    }  
    
}
	
	
	
	
	
	


