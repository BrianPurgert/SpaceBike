package com.doodle.physics2d.full.bike;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.view.View.OnClickListener;

import com.doodle.physics2d.full.bike.Bike;
import com.doodle.physics2d.full.bike.DoodleBikeMain;
import com.doodle.physics2d.graphics.GraphicsWorld;
import com.doodle.physics2d.graphics.SimulationView;    
import com.doodle.physics2d.full.bike.R;




public class Level extends Activity {

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       
        setRequestedOrientation(0);
        setContentView(R.layout.level);
        DoodleBikeMain.controlsvisibility = View.GONE;
        Typeface tf = Typeface.createFromAsset(getAssets(),
        "fonts/Brushed.ttf");
        
        
        SharedPreferences settings = getSharedPreferences("lvlsCompletde", 0);
        DoodleBikeMain.lvlsComplete = settings.getInt("lvlsCompleted", 0);
        
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//   
//                              Load Buttons                               //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
        final Button level1 = (Button) findViewById(R.id.level1);        
        final Button level2 = (Button) findViewById(R.id.level2);       
        final Button level3 = (Button) findViewById(R.id.level3);        
        final Button level4 = (Button) findViewById(R.id.level4);       
        final Button level5 = (Button) findViewById(R.id.level5);               
        final Button level6 = (Button) findViewById(R.id.level6);        
        final Button level7 = (Button) findViewById(R.id.level7);           
        final Button level8 = (Button) findViewById(R.id.level8);        
        final Button level9 = (Button) findViewById(R.id.level9);
        final Button level10 = (Button) findViewById(R.id.level10); 
        final Button level11 = (Button) findViewById(R.id.level11);  
        final Button level12 = (Button) findViewById(R.id.level12);  
        final Button level13 = (Button) findViewById(R.id.level13);  
        final Button level14 = (Button) findViewById(R.id.level14);  
       
        final Button done = (Button) findViewById(R.id.done);
        done.setTypeface(tf);
        
        level1.setTypeface(tf);
        level2.setTypeface(tf);
        level3.setTypeface(tf);
        level4.setTypeface(tf);
        level5.setTypeface(tf);
        level6.setTypeface(tf);
        level7.setTypeface(tf);
        level8.setTypeface(tf);
        level9.setTypeface(tf);
        level10.setTypeface(tf);
        level11.setTypeface(tf);
        level12.setTypeface(tf);
        level13.setTypeface(tf);
        level14.setTypeface(tf);
        
        

  //      final ImageButton back   = (ImageButton) findViewById(R.id.back);       
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//   
//                           initate buttons                               //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//    
        DisplayLevels();
        
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++//
        //                  Bike variable                       //
        //++++++++++++++++++++++++++++++++++++++++++++++++++++++//
		DoodleBikeMain.pickedBike = R.raw.chalkbike; 
		DoodleBikeMain.WheelSpeed = 8; //20 
		GraphicsWorld.biketiltingforce = 1; // 1.5		
		GraphicsWorld.frontwheel = true;
      
		
		
	//	SimulationView.forGroundBottom = true;
		
		
     //  final Intent PlayIntent = new Intent(Level.this,Instructions.class); 
         final    Intent PlayIntent = new Intent(Level.this,DoodleBikeMain.class); 
		level1.setOnClickListener(new View.OnClickListener() {
			public final void onClick(View v) { 	
				LevelControl.Level1(); 				
				 startActivity(PlayIntent);				   
			} 
		});
			
			 
				level2.setOnClickListener(new View.OnClickListener() {
					public final void onClick(View v) { 						
						LevelControl.Level2();
						 startActivity(PlayIntent);
					}
				});
				
					
						level3.setOnClickListener(new View.OnClickListener() {
							public final void onClick(View v) { 
								LevelControl.Level3();
								 startActivity(PlayIntent);
							}
						});
							
							
							level4.setOnClickListener(new View.OnClickListener() {
								public final void onClick(View v) { 
									LevelControl.Level4();
									 startActivity(PlayIntent);
								}
							});
									
							level5.setOnClickListener(new View.OnClickListener() {
								public final void onClick(View v) { 
									LevelControl.Level5();
									 startActivity(PlayIntent);
								} 
							});	 
							level6.setOnClickListener(new View.OnClickListener() {
								public final void onClick(View v) { 
									LevelControl.Level6();
									 startActivity(PlayIntent);
								} 
							});	 
							level7.setOnClickListener(new View.OnClickListener() {
								public final void onClick(View v) { 
									LevelControl.Level7();
									 startActivity(PlayIntent);
								} 
							});	 
							level8.setOnClickListener(new View.OnClickListener() {
								public final void onClick(View v) { 
									LevelControl.Level8();
									 startActivity(PlayIntent); 
								} 
							});	 
							level9.setOnClickListener(new View.OnClickListener() {
								public final void onClick(View v) { 
									LevelControl.Level9();
									 startActivity(PlayIntent); 
								} 
							});
							level10.setOnClickListener(new View.OnClickListener() {
								public final void onClick(View v) { 
									LevelControl.Level10();
									 startActivity(PlayIntent); 
								} 
							});
							level11.setOnClickListener(new View.OnClickListener() {
								public final void onClick(View v) { 
									LevelControl.Level11();
									 startActivity(PlayIntent); 
								} 
							});
							level12.setOnClickListener(new View.OnClickListener() {
								public final void onClick(View v) { 
									LevelControl.Level12();
									 startActivity(PlayIntent); 
								} 
							});
							level13.setOnClickListener(new View.OnClickListener() {
								public final void onClick(View v) { 
									LevelControl.Level13();
									 startActivity(PlayIntent); 
								} 
							});
							level14.setOnClickListener(new View.OnClickListener() {
								public final void onClick(View v) { 
									LevelControl.Level15();
									 startActivity(PlayIntent); 
								} 
							});
							
							done.setOnClickListener(new View.OnClickListener() {
								public final void onClick(View v) { 
									 Intent PlayIntent = new Intent(Level.this,Finish.class);
									 startActivity(PlayIntent);
								} 
							});	 
							
							
							
							 			
		
	   }  
	
	private void DisplayLevels(){
        final Button level1 = (Button) findViewById(R.id.level1);
        final Button level2 = (Button) findViewById(R.id.level2);
        final Button level3 = (Button) findViewById(R.id.level3);
        final Button level4 = (Button) findViewById(R.id.level4);
        final Button level5 = (Button) findViewById(R.id.level5);
        final Button level6 = (Button) findViewById(R.id.level6);
        final Button level7 = (Button) findViewById(R.id.level7);
        final Button level8 = (Button) findViewById(R.id.level8);
        final Button level9 = (Button) findViewById(R.id.level9);
        final Button level10 = (Button) findViewById(R.id.level10); 
        final Button level11 = (Button) findViewById(R.id.level11);  
        final Button level12 = (Button) findViewById(R.id.level12);  
        final Button level13 = (Button) findViewById(R.id.level13);  
        final Button level14 = (Button) findViewById(R.id.level14); 
        
     
        
		  if(DoodleBikeMain.lvlsComplete >= 0){
		    	level1.setVisibility(View.VISIBLE); 
		    } else {
		    	level1.setVisibility(View.GONE);
		    }
		    
		    if(DoodleBikeMain.lvlsComplete >= 1){
		    	level2.setVisibility(View.VISIBLE); 
		    }  else {
		    	level2.setVisibility(View.GONE);
		    }
		    
		    if(DoodleBikeMain.lvlsComplete >= 2){
		    	level3.setVisibility(View.VISIBLE); 
		    }  else {
		    	level3.setVisibility(View.GONE);
		    }
		    
		    if(DoodleBikeMain.lvlsComplete >= 3){
		    	level4.setVisibility(View.VISIBLE); 
		    } else {
		    	level4.setVisibility(View.GONE);
		    }
		    
		    if(DoodleBikeMain.lvlsComplete >= 4){
		    	level5.setVisibility(View.VISIBLE); 
		    } else {
		    	level5.setVisibility(View.GONE);
		    }	
		    
		    if(DoodleBikeMain.lvlsComplete >= 5){
		    	level6.setVisibility(View.VISIBLE); 
		    } else {
		    	level6.setVisibility(View.GONE);
		    }	
		    
		    if(DoodleBikeMain.lvlsComplete >= 6){
		    	level7.setVisibility(View.VISIBLE); 
		    } else {
		    	level7.setVisibility(View.GONE);
		    }	
		    
		    if(DoodleBikeMain.lvlsComplete >= 7){
		    	level8.setVisibility(View.VISIBLE); 
		    } else {
		    	level8.setVisibility(View.GONE);
		    }	
		    if(DoodleBikeMain.lvlsComplete >= 8){
		    	level9.setVisibility(View.VISIBLE); 
		    } else {
		    	level9.setVisibility(View.GONE);
		    }
		    if(DoodleBikeMain.lvlsComplete >= 9){
		    	level10.setVisibility(View.GONE); 
		    } else {
		    	level10.setVisibility(View.GONE);
		    }
		  
		    if(DoodleBikeMain.lvlsComplete >= 10){
		    	level11.setVisibility(View.GONE); 
		    } else {
		    	level11.setVisibility(View.GONE);
		    }
		    if(DoodleBikeMain.lvlsComplete >= 11){
		    	level12.setVisibility(View.GONE); 
		    } else {
		    	level12.setVisibility(View.GONE);
		    }
		    if(DoodleBikeMain.lvlsComplete >= 12){
		    	level13.setVisibility(View.GONE); 
		    } else {
		    	level13.setVisibility(View.GONE);
		    }
		    if(DoodleBikeMain.lvlsComplete >= 13){
		    	level14.setVisibility(View.GONE); 
		    } else {
		    	level14.setVisibility(View.GONE);
		    }
		    
		    
		 
		 //   if(DoodleBikeMain.lvlsComplete >= 3){
		 //   	level6.setVisibility(View.VISIBLE); 
		 //   } else {
		  //  	level6.setVisibility(View.GONE);
		 //   }    
	}

	   protected void onResume() 
	    {
	        super.onResume();
	        SharedPreferences settings = getSharedPreferences("lvlsComplete", 0);
	        DoodleBikeMain.lvlsComplete = settings.getInt("lvlsComplete", 0);
	        DisplayLevels();
	    }  
	
	}
        
							

