/*
 * Doodle Bike source 
 * by Brian Purgert
 * 
 *  * Copyright (c) 2010, DoodleBike - Brian Purgert
 * All rights reserved.
 * 
 * 
 * 
 * Emini Physics engine 
 * by Alexander Adensamer
 * Copyright (c) 2010, Emini Physics - Alexander Adensamer
 * All rights reserved.
 * 

 */

package com.doodle.physics2d.full.bike;

import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.lang.Thread;


import 	android.graphics.Bitmap;
import android.os.Vibrator;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;


import at.emini.physics2D.Body;
import at.emini.physics2D.Event;
import at.emini.physics2D.Motor;
import at.emini.physics2D.PhysicsEventListener;
import at.emini.physics2D.Shape;
import at.emini.physics2D.World;
import at.emini.physics2D.Constraint;
import at.emini.physics2D.util.FXUtil;
import at.emini.physics2D.util.PhysicsFileReader;


import com.doodle.physics2d.full.bike.Level;
import com.doodle.physics2d.full.bike.LevelControl;
import com.doodle.physics2d.full.bike.SoundManager;
import com.doodle.physics2d.graphics.GraphicsWorld;
import com.doodle.physics2d.graphics.SimulationView;
import com.doodle.physics2d.graphics.UserImages;
import com.doodle.physics2d.graphics.SimulationView;
import com.doodle.physics2d.graphics.UserImages;
import com.doodle.physics2d.full.bike.R;

import android.graphics.BitmapShader;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.BitmapDrawable;


public class DoodleBikeMain extends Activity 
{
	//-------Classes-----//		  
	private Handler handler;    	
    private GraphicsWorld world;
    public  World bike;
    public  LevelControl level;
    public  GameEvents events;    
    private SimulationView simulationView;
    private SensorManager mSensorManager;      
//-------Loading Level Variables-----// 
    public static  int background;
    public static int forgroundBottom;
    public static int forgroundTop;
    public static boolean Xaxis;
    public static boolean Drawlandscape;
    public static int pickedWorld;
//-------Loading Bike Variables-----//    
    public static int pickedBike;
    public static int WheelSpeed;
//------Turns on Content Views----//
    public static int controlsvisibility;
    public static boolean theWinMenu;
//------public static boolean theLoseMenu;
    public static boolean CloseControls;
    public static boolean death;
//-------level unlocker-------//
    public static int lvlId;
   public static int lvlsComplete;
//-----Turns of event checking---//  
   private boolean SeeEvents = true;  
   private boolean forwardwasreleased;
   
  public static boolean GravityUp;
  public static boolean GravityDown;
  public static boolean NoGravity;
  public static boolean GravityLeft;
  public static boolean GravityRight;
//--------------------------Time Ticker-------------------------//   
//==============================================================//
//      protected Timer   timeTicker= new Timer("Ticker");        //
//      private   Handler timerHandler    = new Handler();        //
//      protected int     timeTickDown        = 0;               //
//     private int seconds = 0;
//==============================================================//
//----------------------------Sound-----------------------------//   
//==============================================================// 
//       private boolean soundPlaying;                          //
//       private SoundManager mSoundManager;                    //
//==============================================================//   
    
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(0); 
//=================================================//   
//                Set up FX sounds                 //       
//=================================================//     
   //     mSoundManager = new SoundManager();
   //    mSoundManager.initSounds(getBaseContext());
   //     mSoundManager.addSound(1, R.raw.bikeidle);
//=================================================//
  System.out.println("out1");
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        handler = new Handler();

        UserImages.initBitmaps(getResources());        
        createWorld();
        System.out.println("out2");
       simulationView = new GameEvents(this, world);       
       simulationView.setKeepScreenOn(true);

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
//                  Load the bike and add it to the level                    //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//    
        PhysicsFileReader readerTrain = new PhysicsFileReader(getResources().openRawResource(pickedBike));
        GraphicsWorld bike = new GraphicsWorld( World.loadWorld(readerTrain, new UserImages()) );
        world.addWorld(bike);   
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
//                Find the body for centering and Load motors                //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
        System.out.println("out3");
  int bodyCount    = world.getBodyCount();
  Body[] bodies = world.getBodies();
        for( int i = 0; i < bodyCount; i++)        	
        {        	
        	UserImages userShapedata = (UserImages) (bodies[i].shape().getUserData());
            if(userShapedata == null) continue;
            if ( userShapedata.type == UserImages.M_TYPE_BIKE )
            {              
            	simulationView.setViewBody(bodies[i],true,Xaxis);               
            }
            if ( userShapedata.type == UserImages.M_TYPE_ONKILL )
            {             
                         simulationView.setKillBody(bodies[i]);             
            }
        }          
        //-----------Add On bike upside down Event-----------//
               ((GameEvents)simulationView).addEvents();               
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//  
//                            Load Game layouts                              //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//         
        setContentView(R.layout.game);   
        RelativeLayout gamelayout = (RelativeLayout) findViewById(R.id.GameLayout);       
        gamelayout.addView(simulationView, 0);          
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//       
//          Load Background and forground's and set them RGB 565             //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//  
        System.out.println("out4");
      final BitmapFactory.Options options = new BitmapFactory.Options();    
       options.inPreferredConfig = Bitmap.Config.RGB_565;              

       simulationView.setBackground(BitmapFactory.decodeResource(getResources(), background, options));
        
       
       //     BitmapDrawable background = new BitmapDrawable();
       //      Bitmap bitmap1 =  BitmapFactory.decodeResource(getResources(), background, options); //Background   
       //     Bitmap bitmap = BitmapFactory.decodeResource(getResources(), 		background,options);
       // 	if(SimulationView.forGroundBottom == true){
       //      simulationView.setForgroundBottom(BitmapFactory.decodeResource(getResources(), forgroundBottom, options)); //Forground  
       // 	}
       //       BitmapDrawable repeatback = new BitmapDrawable(bitmap1);	
       //  	if(SimulationView.forGroundTop == true){
       //       simulationView.setForgroundTop(BitmapFactory.decodeResource(getResources(), forgroundTop, options)); //Forground   
       //  	}
       //   new BitmapDrawable   BitmapDrawable (Resources res, Bitmap bitmap)
       //    repeatback.setTileModeX(TileMode.REPEAT );
	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++//       
//          Load Up Bitmaps for textures               //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++//    
     	
      //     simulationView.settexture(BitmapFactory.decodeResource(getResources(), R.drawable.blackchalktexture, options));
      //    simulationView.settexture2(BitmapFactory.decodeResource(getResources(), R.drawable.bluechalktexture, options));
         
         
      //     simulationView.settexture3(BitmapFactory.decodeResource(getResources(), R.drawable.yellow, options));
      
      //       simulationView.setp1(BitmapFactory.decodeResource(getResources(), R.drawable.smoke1, options));
      //   simulationView.setp2(BitmapFactory.decodeResource(getResources(), R.drawable.0, options));
      //   simulationView.setp3(BitmapFactory.decodeResource(getResources(), R.drawable.0, options));
      //   simulationView.setp4(BitmapFactory.decodeResource(getResources(), R.drawable.0, options));
//+++++++++++++++++++++++++++++++++++++++++++++++++++++//       
//                  set up shaders                     //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++// 
       //  final BitmapShader background  = new BitmapShader(SimulationView.backGroundImage, TileMode .REPEAT, TileMode .REPEAT ); //mirror clamp repeat
       //    GraphicsWorld.renderBackground.setShader(background);
         
         
        //    final BitmapShader yellowChalk  = new BitmapShader(SimulationView.landscapetexture, TileMode .REPEAT, TileMode .REPEAT ); //mirror clamp repeat
        //      GraphicsWorld.renderLandscape.setShader(yellowChalk);
          
        //    final  BitmapShader blueChalk  = new BitmapShader(SimulationView.landscapetexture2, TileMode .REPEAT, TileMode .REPEAT ); //mirror clamp repeat
        //     GraphicsWorld.renderBodies.setShader(blueChalk);
        //     GraphicsWorld.renderStaticBodies.setShader(blueChalk);
      
       //     final  BitmapShader yellow  = new BitmapShader(SimulationView.landscapetextureback, TileMode .REPEAT, TileMode .REPEAT ); //mirror clamp repeat
       //      GraphicsWorld.black4.setShader(yellow);
          
//++++++++++++++++++++++++++++++++++++++++++//       
//        set menus to not display          //
//++++++++++++++++++++++++++++++++++++++++++//            
    	theWinMenu = false; 
    	death = false;  
    	GravityUp = false;
//++++++++++++++++++++++++++++++++++++++++++//
//      Initiate Motors and put motors      //      
//++++++++++++++++++++++++++++++++++++++++++//        
        world.initMotors();
        world.putmotor();   
		//   time.setText(seconds + "." +timeTickDown);
     
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//  
//                  Initiate Forward and Backward buttons                    //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//        	    
//                    Forward                   //
//----------------------------------------------//
//   	 timeTicker.scheduleAtFixedRate(tick, 0, 100);
       forwardwasreleased = true;       
        final Button forward = (Button) findViewById(R.id.forward);
		 forward.setOnTouchListener(new View.OnTouchListener() {	  			
			public final boolean onTouch(View v, MotionEvent down) {		
				
			if	(forwardwasreleased == true) {
				world.putmotor();				
				world.setWheelSpeed(WheelSpeed);
			//	soundPlaying = true;
				forwardwasreleased = false;
			}
			/* 
		   	 timeTicker.scheduleAtFixedRate(tick, 0, 100);

		    */
				return false;	
			} 
	       	 });
		//----------------------------------------------//        
        forward.setOnClickListener(new View.OnClickListener() {
            public final void onClick(View v) { 
            	
            	world.takemotor();
            	world.setWheelSpeed(-4); 
            //	soundPlaying = false;
            	forwardwasreleased = true;          	
           } 
             }); 
        //---------------------------------------------//
        //                   Reverse                   //
        //---------------------------------------------//
        final Button reverse = (Button) findViewById(R.id.reverse);
		 reverse.setOnTouchListener(new View.OnTouchListener() {	  			
			public final boolean onTouch(View v, MotionEvent down) {	
				System.out.println("reverse pressed");
				world.putmotor();
				world.setWheelSpeed(-4);	
				return false;	
			} 
	       	 });
        //----------------------------------------------//		 
        reverse.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { 
            	System.out.println("reverse released");
            	world.takemotor();
                world.setWheelSpeed(0);
                
            } 
        });    
   		 	 
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//  
//                         Buttons For the menus                             //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++// 
      
        Typeface sketch = Typeface.createFromAsset(getAssets(),
        "fonts/sketch.ttf"); 
        
        final Button mainmenu  = (Button) findViewById(R.id.mainmenu);
        final Button restart   = (Button) findViewById(R.id.restart); 
        final Button nextlevel = (Button) findViewById(R.id.nextlevel);       
        final ImageButton restart2  = (ImageButton) findViewById(R.id.restart2);
        final ImageButton openmenu  = (ImageButton) findViewById(R.id.openmenu);        
        final ImageButton back      = (ImageButton) findViewById(R.id.back);
        final	Intent PlayIntent = new Intent(DoodleBikeMain.this,DoodleBikeMain.class);
        
        
        mainmenu.setTypeface(sketch);
        restart.setTypeface(sketch);
        nextlevel.setTypeface(sketch);
        //-----------------Go To Level Select-------------//        
        mainmenu.setOnClickListener(new View.OnClickListener() {
	            public final void onClick(View v) { 	            		            	
	            	finish();
	            	Intent MainMenuIntent = new Intent(DoodleBikeMain.this,Level.class);
	        		startActivity(MainMenuIntent);
	           } 
	             });   
		    	    
        //-----------------Reload Game Intent-------------//        
		    restart.setOnClickListener(new View.OnClickListener() {
	            public final void onClick(View v) { 	            	            	            		            	
	            	    	finish();	                 
		        		startActivity(PlayIntent);            	
	           } 
	             }); 		  		 
	   //-----------------Reload Game Intent-------------//
		    restart2.setOnClickListener(new View.OnClickListener() {
	            public final void onClick(View v) { 
	            	finish();	            	    
		        		startActivity(PlayIntent);	
	           } 
	             });  
		    
		  //-----------------Open up in game menu-------------//
		    openmenu.setOnClickListener(new View.OnClickListener() {
	            public final void onClick(View v) {  
	            	final RelativeLayout open = (RelativeLayout) findViewById(R.id.RelativeLayout01);
	            	 	back.setVisibility(View.VISIBLE);
	            	 	nextlevel.setVisibility(View.INVISIBLE);
	            	 	forward.setVisibility(View.INVISIBLE);    		    		
	            	 	open.setVisibility(View.VISIBLE); 
	            } 
            });
		  //-----------------Back to game from menu-------------//
		    back.setOnClickListener(new View.OnClickListener() {
	            public final void onClick(View v) { 
	            final	RelativeLayout flip = (RelativeLayout) findViewById(R.id.RelativeLayout01);
	            		forward.setVisibility(View.VISIBLE);    		
	            		flip.setVisibility(View.GONE); 
	            } 
            });
		  //-----------------Picks the next level-------------//
		    nextlevel.setOnClickListener(new View.OnClickListener() {
		    
	            public final void onClick(View v) { 	
	          //  	Intent MainMenuIntent = new Intent(DoodleBikeMain.this,Bike.class);
	            	 switch (lvlId) {
	                 case 1:  LevelControl.Level2();  finish(); startActivity(PlayIntent); break;
	                 case 2:  LevelControl.Level3();  finish(); startActivity(PlayIntent); break;
	                 case 3:  LevelControl.Level4();  finish(); startActivity(PlayIntent); break;
	                 case 4:  LevelControl.Level5();  finish(); startActivity(PlayIntent); break;
	                 case 5:  LevelControl.Level6();  finish(); startActivity(PlayIntent); break;
	                 case 6:  LevelControl.Level7();  finish(); startActivity(PlayIntent); break;
	                 case 7:  LevelControl.Level8();  finish(); startActivity(PlayIntent); break;
	                 case 8:  LevelControl.Level9();  finish(); startActivity(PlayIntent); break;
	                 
	                 case 9: Finished ();  break;
	     //            case 10:  LevelControl.Level11();  finish(); startActivity(MainMenuIntent); break;
	     //            case 11:  LevelControl.Level12();  finish(); startActivity(MainMenuIntent); break;
	     //            case 12:  LevelControl.Level13();  finish(); startActivity(MainMenuIntent); break;
	     //            case 13:  LevelControl.Level14();  finish(); startActivity(MainMenuIntent); break;
	     //            case 14:  LevelControl.Level15();  finish(); startActivity(MainMenuIntent); break;
	     //            case 15:  LevelControl.Level16();  finish(); startActivity(MainMenuIntent); break;
	    //             case 16:  LevelControl.Level17();  finish(); startActivity(MainMenuIntent); break;
	              
	               }  	 
                    	
	           } 
	             }); 				  
    } 
        //----------------------------------------------//
    
    private final void Finished (){
    	finish();	
    	Intent rate = new Intent(DoodleBikeMain.this,Finish.class); 
    	startActivityForResult(rate,0);
    }
//--------------------//    
	@Override
    protected void onPause() 
    {

        super.onPause();

        handler.removeCallbacks(update);
        mSensorManager.unregisterListener(world);        
   
    }
//--------------------// 
    @Override
    protected void onResume() 
    {
        super.onResume();
        handler.post(update);

        if (world != null)
        {
            mSensorManager.registerListener(world, 
                    SensorManager.SENSOR_ACCELEROMETER,
                    SensorManager.SENSOR_DELAY_GAME);
        }

    }  
//--------------------// 
    public GraphicsWorld createWorld()
    {                
        PhysicsFileReader reader = new PhysicsFileReader(getResources().openRawResource(pickedWorld));
        world = new GraphicsWorld( World.loadWorld(reader, new UserImages()) );
        world.setDrawLandscape(Drawlandscape);
        mSensorManager.registerListener(world, 
                SensorManager.SENSOR_ACCELEROMETER,
                SensorManager.SENSOR_DELAY_GAME);
        return world;
    }  
    
   
    
    private final void UnlockLevel(){
    	
		switch (lvlId) {
         case 1:  if(lvlsComplete == 0){lvlsComplete = 1;}   break;
         case 2:  if(lvlsComplete == 1){lvlsComplete = 2;}   break;
         case 3:  if(lvlsComplete == 2){lvlsComplete = 3;}   break;
         case 4:  if(lvlsComplete == 3){lvlsComplete = 4;}   break;
         case 5:  if(lvlsComplete == 4){lvlsComplete = 5;}   break;
         case 6:  if(lvlsComplete == 5){lvlsComplete = 6;}   break;
         case 7:  if(lvlsComplete == 6){lvlsComplete = 7;}   break;
         case 8:  if(lvlsComplete == 7){lvlsComplete = 8;}   break;
         case 9:  if(lvlsComplete == 8){lvlsComplete = 9;}   break;
         case 10: if(lvlsComplete == 9){lvlsComplete = 10;}  break;
         case 11: if(lvlsComplete == 10){lvlsComplete = 11;} break;
         case 12: if(lvlsComplete == 11){lvlsComplete = 12;} break;
         
         case 13:  if(lvlsComplete == 12){lvlsComplete = 13;}   break;
         case 14:  if(lvlsComplete == 13){lvlsComplete = 14;}   break;
         case 15:  if(lvlsComplete == 14){lvlsComplete = 15;}   break;

         default: lvlsComplete = 1; lvlId = 1; break;
     }  	 
    }
    
    
    
    private final void checkEvents(){
    	  final Button forward = (Button) findViewById(R.id.forward);   	  
    	  final Button nextlevel = (Button) findViewById(R.id.nextlevel);    	  
    	  final ImageButton back = (ImageButton) findViewById(R.id.back);
    	  
    	  
    	  final RelativeLayout flip    = (RelativeLayout) findViewById(R.id.RelativeLayout01);
    	  final RelativeLayout winmenu = (RelativeLayout) findViewById(R.id.RelativeLayout01);
    	  final View     arrow   = (View)           findViewById(R.id.arrow);
    	  
    	if (DoodleBikeMain.theWinMenu == true){    		
    		forward.setVisibility(View.INVISIBLE);
    		nextlevel.setVisibility(View.VISIBLE);
    		back.setVisibility(View.INVISIBLE); 
    		winmenu.setVisibility(View.VISIBLE);    		
    			world.putmotor();
    			world.setWheelSpeed(0);
    				UnlockLevel();    		
           				SharedPreferences settings = getSharedPreferences("lvlsComplete", 0);
           				SharedPreferences.Editor editor = settings.edit();
           				editor.putInt("lvlsComplete", lvlsComplete);
           				editor.commit();               
           			//	SeeEvents = false;  		
        	}    
    	
    	if (DoodleBikeMain.death == true){  
    		world.destroyBike();
    		Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
    		v.vibrate(300);      		
    		SeeEvents = false;
    		DoodleBikeMain.death = false;
    		    		  
    		        forward.setVisibility(View.INVISIBLE);
    				nextlevel.setVisibility(View.INVISIBLE);    				
    				back.setVisibility(View.INVISIBLE);  
    				flip.setVisibility(View.VISIBLE); 
        	}
 	// Gravity changer
        	if (DoodleBikeMain.GravityUp == true){  
        		arrow.setBackgroundResource(R.drawable.arrowup);
        		world.setNewGravity(0,-130);  
        		GravityUp = false;        		
       } 
        	if (DoodleBikeMain.GravityDown == true){
        		arrow.setBackgroundResource(R.drawable.arrowdown);
    	   world.setNewGravity(0,130);
    	   GravityDown = false;
       }
        	if (DoodleBikeMain.NoGravity == true){
        		arrow.setBackgroundResource(R.drawable.nogravity);
         	   world.setNewGravity(0,0);
         	   NoGravity = false;
            }
        
        	if (DoodleBikeMain.GravityLeft == true){
        		arrow.setBackgroundResource(R.drawable.arrowleft);
          	   world.setNewGravity(-130,0);
          	 GravityLeft = false;
             }
        	if (DoodleBikeMain.GravityRight == true){
        		arrow.setBackgroundResource(R.drawable.arrowright);
           	   world.setNewGravity(130,0);
           	 GravityRight = false;
              }
        	
	} 
    	
   
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
//                     Main Game Activity Intent Timer                       //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//  

/*
  	final TextView time = (TextView)findViewById(R.id.time);
    
    
    
    protected TimerTask tick = new TimerTask() {
        public void run() {
            myTickTask();
         
        }
    };

    protected void myTickTask() {
        if (timeTickDown == 10) { 
            timerHandler.post(doUpdateTimeout);
        }
        timeTickDown++;  
        
        System.out.println(seconds + "." +timeTickDown);
        
    }

    private Runnable doUpdateTimeout = new Runnable() {
        public void run() {
            updateTimeout(); 
        }
    };
    
    private void updateTimeout() {
        timeTickDown = 0; // 10* 100ms == once a second    
          seconds++;
          
    }
    
  */
   //++++++++++++++++++++++++++++++++++++++++++++++++++++++//
   //                       Threads                        //
   //++++++++++++++++++++++++++++++++++++++++++++++++++++++//
    //+++++++++++++++++++++++++++++++++++//
    //               SOUND               //
    //+++++++++++++++++++++++++++++++++++//
    /*
    private Runnable mythread = new Runnable() {
    	
        public void run() {  
        	System.out.println("runnable");
       if(soundPlaying == true){
    	   mSoundManager.playSound(1);
    	//   long bob = 2500;
    //	   sleep( bob);
    	   // waiting(2500);    	 
       }
     //  handler.postDelayed(mythread,0);
       
        }
    }; 
    
*/
  
    
    
 //   private void PlaySound(){
 //   	mSoundManager.playSound(1);
 //    } 
 
 /*     public static void waiting (int n){
    	         
    	         long t0, t1;
    	 
    	         t0 =  System.currentTimeMillis();
    	 
    	         do{
    	             t1 = System.currentTimeMillis();
    	         }
    	         while (t1 - t0 < n);
    	     }
    */
    //+++++++++++++++++++++++++++++++++++//
    //           Update World            //
    //+++++++++++++++++++++++++++++++++++//
    private Runnable update = new Runnable() 
    {
        public void run() 
        {              
            long start = System.currentTimeMillis(); 
            	simulationView.tickWorld();
            		if  (SeeEvents == true){   checkEvents();  } 
            	
            long end = System.currentTimeMillis();
      //      System.out.println(end - start);
            handler.postDelayed(update, (long) Math.max( 40 - (end - start), 0));
        }  
    };
//--------------------//      
}