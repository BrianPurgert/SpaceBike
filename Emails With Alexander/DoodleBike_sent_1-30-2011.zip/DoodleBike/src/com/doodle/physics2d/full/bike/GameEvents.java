
package com.doodle.physics2d.full.bike;

import android.content.Context;
import android.content.Intent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import at.emini.physics2D.Body;
import at.emini.physics2D.Contact;
import at.emini.physics2D.Event;
import at.emini.physics2D.PhysicsEventListener;
import at.emini.physics2D.World;
import android.app.Activity;
import android.view.View.OnTouchListener;

import com.doodle.physics2d.graphics.GraphicsWorld;
import com.doodle.physics2d.graphics.SimulationView;
import com.doodle.physics2d.graphics.UserImages;



public class GameEvents extends SimulationView implements PhysicsEventListener
{
//	DoodleBikeMain game;
    public GameEvents(Context context, GraphicsWorld world)
    {
        super(context, world);
       world.setPhysicsEventListener(this);
    }
    
  
    
    
    public void addEvents()
    {
      Event event = Event.createBodyEvent(killBody, null, Event.TYPE_BODY_COLLISION, 0, 0, 1, 0);    
      world.addEvent(event);
    }

     public void eventTriggered(Event event, Object object) {
       
    	 System.out.println("Event occurred: " + event.type() + " -- "  + event.getIdentifier()  + " -- " + object);
    
    	 //event ids
    	 // area event 0 = win game
    	 // area event 1 is lose game due to falling
    	 // area event 2 is close controls for first thing
    	 // 3 should be death due to flipping over    	
           if ( object instanceof Contact)
          {
               Contact c = (Contact) object; 
               System.out.println("Contact: ");
               c.getContactPosition1().dumpToConsole("\n");
               c.getContactPosition2().dumpToConsole("\n");
          }
    	 
    //	event.id();
    	if (event.getIdentifier() == 0){
    		DoodleBikeMain.theWinMenu = true; 
    	}
    	if (event.getIdentifier() == 1 || event.getIdentifier() == 7){
    		DoodleBikeMain.death = true; 
    	}
    	if (event.getIdentifier() == 2 || event.getIdentifier() == 8){
    		DoodleBikeMain.GravityUp = true; 
    	}
    	if (event.getIdentifier() == 3 || event.getIdentifier() == 9){
    		DoodleBikeMain.GravityDown = true; 
    	}
    	if (event.getIdentifier() == 4 || event.getIdentifier() == 10){
    		DoodleBikeMain.NoGravity = true; 
    	}
    	
    	if (event.getIdentifier() == 5 || event.getIdentifier() == 11){
    		DoodleBikeMain.GravityLeft = true; 
    	}
    	if (event.getIdentifier() == 6 || event.getIdentifier() == 12){
    		DoodleBikeMain.GravityRight = true; 
    	}
    	
    	if (event.getIdentifier() == 13  ){   	
    		DoodleBikeMain.death = true; 
    	}
    	
    	//----first level-----//
 		 
   // 	if(DoodleBikeMain.lvlId == 1 &&  event.getIdentifier() == 3){
   //     	DoodleBikeMain.death = true;     		
   // 	}
       //---------------//	

   // 	if(DoodleBikeMain.lvlId > 1 &&  event.getIdentifier() == 2){
   //    	DoodleBikeMain.death = true;     		
   // 	}  
    	
    	
    	
     } 
}
