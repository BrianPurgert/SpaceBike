package com.doodle.physics2d.full.bike;

import android.content.Intent;
import android.graphics.Color;
import android.view.View;

import com.doodle.physics2d.graphics.GraphicsWorld;
import com.doodle.physics2d.graphics.SimulationView;
import com.doodle.physics2d.graphics.UserImages;
import com.doodle.physics2d.full.bike.R;

public class LevelControl {

	// -------- Levels --------//
	public static final void Level1(){						
		DoodleBikeMain.Xaxis = true;                       // If the camera goes up and down
		
		SimulationView.XViewPosition = 4;     //  Is the distance in pixels from the center of the screen to the viewBody in the x axis
		SimulationView.YViewPosition = 6;     //  Is the distance in pixels from the center of the screen to the viewBody in the y axis
		SimulationView.UpDownDelay= 1;
		
		DoodleBikeMain.Drawlandscape = true;                // Draw Landscape 
		DoodleBikeMain.pickedWorld = R.raw.practice0;			 // World to load	
			
		DoodleBikeMain.background = R.drawable.main;		             // background image on bottom layer    ex: the actual background image like a sky or ocean
		SimulationView.BGX = (float) 0;			     	               	 // The Position at which the Image starts
		SimulationView.BGY = (float) 0; 
		SimulationView.BGRateX = (float) .4;			     			      // The rate at which the background moves
		SimulationView.BGRateY = (float) 0; 
		
		SimulationView.forGroundBottom = false;
		DoodleBikeMain.forgroundBottom = 0;		         // forground image in middle layer    ex: trees/clouds/sun 
		SimulationView.FGBX = (float) 0;			     		     	 // The Position at which the Image starts
		SimulationView.FGBY = (float) 0;
		SimulationView.FGBRateX = (float) .4;			     			 // The rate at which the Bottom Forground moves
		SimulationView.FGBRateY = (float) .1; 
		
		SimulationView.forGroundTop =false;
		DoodleBikeMain.forgroundTop = 0;		         // forground image on top layer   ex: the actual object the player will ride on
		SimulationView.FGTX = (float) 0;			     			     // The Position at which the Image starts
		SimulationView.FGTY = (float) 0;
		SimulationView.FGTRateX = (float) 0;			     			 // The rate at which the Top Forground moves
		SimulationView.FGTRateY = (float) 0;      
	     
	     DoodleBikeMain.lvlId = 1;  // for unlocking levels	and determining the level     	
		 
	}
	
	
	public static final void Level2(){						
		DoodleBikeMain.Xaxis = true;                       // If the camera goes up and down
		
		SimulationView.XViewPosition = 4;     //  Is the distance in pixels from the center of the screen to the viewBody in the x axis
		SimulationView.YViewPosition = 10;     //  higher number is for high starting point going low, vise versa
		SimulationView.UpDownDelay= 1.4;
		
		DoodleBikeMain.Drawlandscape = true;                // Draw Landscape 
		DoodleBikeMain.pickedWorld = R.raw.practice1;			 // World to load	
			
		DoodleBikeMain.background = R.drawable.main;		             // background image on bottom layer    ex: the actual background image like a sky or ocean
		SimulationView.BGX = (float) 0;			     	               	 // The Position at which the Image starts
		SimulationView.BGY = (float) 0; 
		SimulationView.BGRateX = (float) .2;			     			      // The rate at which the background moves
		SimulationView.BGRateY = (float) 0; 
		
		SimulationView.forGroundBottom = false;
		DoodleBikeMain.forgroundBottom = 0;		         // forground image in middle layer    ex: trees/clouds/sun 
		SimulationView.FGBX = (float) 0;			     		     	 // The Position at which the Image starts
		SimulationView.FGBY = (float) 0;
		SimulationView.FGBRateX = (float) .4;			     			 // The rate at which the Bottom Forground moves
		SimulationView.FGBRateY = (float) .1; 
		
		SimulationView.forGroundTop = false;
		DoodleBikeMain.forgroundTop = 0;		         // forground image on top layer   ex: the actual object the player will ride on
		SimulationView.FGTX = (float) 0;			     			     // The Position at which the Image starts
		SimulationView.FGTY = (float) 0;
		SimulationView.FGTRateX = (float) 0;			     			 // The rate at which the Top Forground moves
		SimulationView.FGTRateY = (float) 0; 
		     
	     
	     DoodleBikeMain.lvlId = 2;  // for unlocking levels	and determining the level     	
		 
	}
	
	public static final void Level3(){						
		DoodleBikeMain.Xaxis = true;                       // If the camera goes up and down
		
		SimulationView.XViewPosition = 2;     //  Is the distance in pixels from the center of the screen to the viewBody in the x axis
		SimulationView.YViewPosition = 10;     //  Is the distance in pixels from the center of the screen to the viewBody in the y axis
		SimulationView.UpDownDelay= 1.4;
		
		DoodleBikeMain.Drawlandscape = true;                // Draw Landscape 
		DoodleBikeMain.pickedWorld = R.raw.level0;			 // World to load	
			
		DoodleBikeMain.background = R.drawable.main;		             // background image on bottom layer    ex: the actual background image like a sky or ocean
		SimulationView.BGX = (float) 0;			     	               	 // The Position at which the Image starts
		SimulationView.BGY = (float) 0; 
		SimulationView.BGRateX = (float) .2;			     			      // The rate at which the background moves
		SimulationView.BGRateY = (float) 0; 
		
		SimulationView.forGroundBottom = false;
		DoodleBikeMain.forgroundBottom = 0;		         // forground image in middle layer    ex: trees/clouds/sun 
		SimulationView.FGBX = (float) 0;			     		     	 // The Position at which the Image starts
		SimulationView.FGBY = (float) 0;
		SimulationView.FGBRateX = (float) .4;			     			 // The rate at which the Bottom Forground moves
		SimulationView.FGBRateY = (float) .1; 
		
		SimulationView.forGroundTop = false;
		DoodleBikeMain.forgroundTop = 0;		         // forground image on top layer   ex: the actual object the player will ride on
		SimulationView.FGTX = (float) 0;			     			     // The Position at which the Image starts
		SimulationView.FGTY = (float) 0;
		SimulationView.FGTRateX = (float) 0;			     			 // The rate at which the Top Forground moves
		SimulationView.FGTRateY = (float) 0; 
	     
	     DoodleBikeMain.lvlId = 3;  // for unlocking levels	and determining the level     	
		 
	}
	
	public static final void Level4(){						
		DoodleBikeMain.Xaxis = true;                       // If the camera goes up and down
		
		SimulationView.XViewPosition = 4;     //  Is the distance in pixels from the center of the screen to the viewBody in the x axis
		SimulationView.YViewPosition = 5;     //  Is the distance in pixels from the center of the screen to the viewBody in the y axis
		SimulationView.UpDownDelay= 1.4;
		
		DoodleBikeMain.Drawlandscape = true;                // Draw Landscape 
		DoodleBikeMain.pickedWorld = R.raw.practice2;			 // World to load	
			
		DoodleBikeMain.background = R.drawable.main;		             // background image on bottom layer    ex: the actual background image like a sky or ocean
		SimulationView.BGX = (float) 0;			     	               	 // The Position at which the Image starts
		SimulationView.BGY = (float) 0; 
		SimulationView.BGRateX = (float) .2;			     			      // The rate at which the background moves
		SimulationView.BGRateY = (float) 0; 
		
		SimulationView.forGroundBottom = false;
		DoodleBikeMain.forgroundBottom = 0;		         // forground image in middle layer    ex: trees/clouds/sun 
		SimulationView.FGBX = (float) 0;			     		     	 // The Position at which the Image starts
		SimulationView.FGBY = (float) 0;
		SimulationView.FGBRateX = (float) .4;			     			 // The rate at which the Bottom Forground moves
		SimulationView.FGBRateY = (float) .1; 
		
		SimulationView.forGroundTop = false;
		DoodleBikeMain.forgroundTop = 0;		         // forground image on top layer   ex: the actual object the player will ride on
		SimulationView.FGTX = (float) 0;			     			     // The Position at which the Image starts
		SimulationView.FGTY = (float) 0;
		SimulationView.FGTRateX = (float) 0;			     			 // The rate at which the Top Forground moves
		SimulationView.FGTRateY = (float) 0;      
	     
	     DoodleBikeMain.lvlId = 4;  // for unlocking levels	and determining the level     	
		 
	}
	
	public static final void Level5(){						
		DoodleBikeMain.Xaxis = true;                       // If the camera goes up and down
		
		SimulationView.XViewPosition = 4;     //  Is the distance in pixels from the center of the screen to the viewBody in the x axis
		SimulationView.YViewPosition = 10;     //  Is the distance in pixels from the center of the screen to the viewBody in the y axis
		SimulationView.UpDownDelay= 1.4;
		
		DoodleBikeMain.Drawlandscape = true;                // Draw Landscape 
		DoodleBikeMain.pickedWorld = R.raw.level1;			 // World to load	
			
		DoodleBikeMain.background = R.drawable.main;		             // background image on bottom layer    ex: the actual background image like a sky or ocean
		SimulationView.BGX = (float) 0;			     	               	 // The Position at which the Image starts
		SimulationView.BGY = (float) 0; 
		SimulationView.BGRateX = (float) .2;			     			      // The rate at which the background moves
		SimulationView.BGRateY = (float) 0; 
		
		SimulationView.forGroundBottom = false;
		DoodleBikeMain.forgroundBottom = 0;		         // forground image in middle layer    ex: trees/clouds/sun 
		SimulationView.FGBX = (float) 0;			     		     	 // The Position at which the Image starts
		SimulationView.FGBY = (float) 0;
		SimulationView.FGBRateX = (float) .4;			     			 // The rate at which the Bottom Forground moves
		SimulationView.FGBRateY = (float) .1; 
		
		SimulationView.forGroundTop = false;
		DoodleBikeMain.forgroundTop = 0;		         // forground image on top layer   ex: the actual object the player will ride on
		SimulationView.FGTX = (float) 0;			     			     // The Position at which the Image starts
		SimulationView.FGTY = (float) 0;
		SimulationView.FGTRateX = (float) 0;			     			 // The rate at which the Top Forground moves
		SimulationView.FGTRateY = (float) 0;     
	     
	     DoodleBikeMain.lvlId = 5;  // for unlocking levels	and determining the level     	
		 
	}
	
	public static final void Level6(){						
		DoodleBikeMain.Xaxis = true;                       // If the camera goes up and down
		
		SimulationView.XViewPosition = 4;     //  Is the distance in pixels from the center of the screen to the viewBody in the x axis
		SimulationView.YViewPosition = 10;     //  Is the distance in pixels from the center of the screen to the viewBody in the y axis
		SimulationView.UpDownDelay= 1.4;
		
		DoodleBikeMain.Drawlandscape = true;                // Draw Landscape 
		DoodleBikeMain.pickedWorld = R.raw.level2;			 // World to load	
			
		DoodleBikeMain.background = R.drawable.main;		             // background image on bottom layer    ex: the actual background image like a sky or ocean
		SimulationView.BGX = (float) 0;			     	               	 // The Position at which the Image starts
		SimulationView.BGY = (float) 0; 
		SimulationView.BGRateX = (float) .2;			     			      // The rate at which the background moves
		SimulationView.BGRateY = (float) 0; 
		
		SimulationView.forGroundBottom = false;
		DoodleBikeMain.forgroundBottom = 0;		         // forground image in middle layer    ex: trees/clouds/sun 
		SimulationView.FGBX = (float) 0;			     		     	 // The Position at which the Image starts
		SimulationView.FGBY = (float) 0;
		SimulationView.FGBRateX = (float) .4;			     			 // The rate at which the Bottom Forground moves
		SimulationView.FGBRateY = (float) .1; 
		
		SimulationView.forGroundTop = false;
		DoodleBikeMain.forgroundTop = 0;		         // forground image on top layer   ex: the actual object the player will ride on
		SimulationView.FGTX = (float) 0;			     			     // The Position at which the Image starts
		SimulationView.FGTY = (float) 0;
		SimulationView.FGTRateX = (float) 0;			     			 // The rate at which the Top Forground moves
		SimulationView.FGTRateY = (float) 0;      
	     
	     DoodleBikeMain.lvlId = 6;  // for unlocking levels	and determining the level     	
		 
	}
	
	public static final void Level7(){						
		DoodleBikeMain.Xaxis = true;                       // If the camera goes up and down
		
		SimulationView.XViewPosition = 4;     //  Is the distance in pixels from the center of the screen to the viewBody in the x axis
		SimulationView.YViewPosition = 10;     //  Is the distance in pixels from the center of the screen to the viewBody in the y axis
		SimulationView.UpDownDelay= 1.4;
		
		DoodleBikeMain.Drawlandscape = true;                // Draw Landscape 
		DoodleBikeMain.pickedWorld = R.raw.level3;			 // World to load	
			
		DoodleBikeMain.background = R.drawable.main;		             // background image on bottom layer    ex: the actual background image like a sky or ocean
		SimulationView.BGX = (float) 0;			     	               	 // The Position at which the Image starts
		SimulationView.BGY = (float) 0; 
		SimulationView.BGRateX = (float) .2;			     			      // The rate at which the background moves
		SimulationView.BGRateY = (float) 0; 
		
		SimulationView.forGroundBottom = false;
		DoodleBikeMain.forgroundBottom = 0;		         // forground image in middle layer    ex: trees/clouds/sun 
		SimulationView.FGBX = (float) 0;			     		     	 // The Position at which the Image starts
		SimulationView.FGBY = (float) 40;
		SimulationView.FGBRateX = (float) .4;			     			 // The rate at which the Bottom Forground moves
		SimulationView.FGBRateY = (float) .1; 
		
		SimulationView.forGroundTop = false;
		DoodleBikeMain.forgroundTop = R.drawable.cpaper;		         // forground image on top layer   ex: the actual object the player will ride on
		SimulationView.FGTX = (float) 0;			     			     // The Position at which the Image starts
		SimulationView.FGTY = (float) 0;
		SimulationView.FGTRateX = (float) 0;			     			 // The rate at which the Top Forground moves
		SimulationView.FGTRateY = (float) 0;       
	     
	     DoodleBikeMain.lvlId = 7;  // for unlocking levels	and determining the level     	
		 
	}
	
	
	
	public static final void Level8(){								
		defaultSettings();               
		DoodleBikeMain.pickedWorld = R.raw.level4;			 	     
	     DoodleBikeMain.lvlId = 8;      			 
	}
	public static  final void Level9(){
		DoodleBikeMain.Xaxis = true;
		SimulationView.XViewPosition = 2;     //  Is the distance in pixels from the center of the screen to the viewBody in the x axis
		SimulationView.YViewPosition = 5;     //  Is the distance in pixels from the center of the screen to the viewBody in the y axis
		SimulationView.UpDownDelay= 1;
		
		DoodleBikeMain.Drawlandscape = true;                // Draw Landscape 
		DoodleBikeMain.pickedWorld = R.raw.level3;			 // World to load	
			
		DoodleBikeMain.background = R.drawable.main;		             // background image on bottom layer    ex: the actual background image like a sky or ocean
		SimulationView.BGX = (float) 0;			     	               	 // The Position at which the Image starts
		SimulationView.BGY = (float) 0; 
		SimulationView.BGRateX = (float) .2;			     			      // The rate at which the background moves
		SimulationView.BGRateY = (float) 0; 
		
		SimulationView.forGroundBottom = false;
		DoodleBikeMain.forgroundBottom = 0;		         // forground image in middle layer    ex: trees/clouds/sun 
		SimulationView.FGBX = (float) 0;			     		     	 // The Position at which the Image starts
		SimulationView.FGBY = (float) 40;
		SimulationView.FGBRateX = (float) .4;			     			 // The rate at which the Bottom Forground moves
		SimulationView.FGBRateY = (float) .1; 
		
		SimulationView.forGroundTop = false;
		DoodleBikeMain.forgroundTop = R.drawable.cpaper;		         // forground image on top layer   ex: the actual object the player will ride on
		SimulationView.FGTX = (float) 0;			     			     // The Position at which the Image starts
		SimulationView.FGTY = (float) 0;
		SimulationView.FGTRateX = (float) 0;			     			 // The rate at which the Top Forground moves
		SimulationView.FGTRateY = (float) 0;        
		DoodleBikeMain.pickedWorld = R.raw.level5;			 	     
	     DoodleBikeMain.lvlId = 9;      			 
	}
	public static void Level10(){								
		defaultSettings();               
	//	DoodleBikeMain.pickedWorld = R.raw.level6;			 	     
	     DoodleBikeMain.lvlId = 10;      			 
	}
	public static void Level11(){								
		defaultSettings();               
//		DoodleBikeMain.pickedWorld = R.raw.level7;			 	     
	     DoodleBikeMain.lvlId = 11;      			 
	}
	public static void Level12(){								
		defaultSettings();               
//		DoodleBikeMain.pickedWorld = R.raw.level8;			 	     
	     DoodleBikeMain.lvlId = 12;      			 
	}
	public static void Level13(){								
		defaultSettings();               
//		DoodleBikeMain.pickedWorld = R.raw.level9;			 	     
	     DoodleBikeMain.lvlId = 13;      			 
	}
	public static void Level14(){								
		defaultSettings();               
//		DoodleBikeMain.pickedWorld = R.raw.level10;			 	     
	     DoodleBikeMain.lvlId = 14;      			 
	}
	public static void Level15(){								
		defaultSettings();               
//		DoodleBikeMain.pickedWorld = R.raw.level11;			 	     
	     DoodleBikeMain.lvlId = 15;      			 
	}

private static final void defaultSettings(){
	DoodleBikeMain.Xaxis = true;                     
	
	SimulationView.XViewPosition = 4;     
	SimulationView.YViewPosition = 10; 
	SimulationView.UpDownDelay= 1.4;
	DoodleBikeMain.Drawlandscape = true; 
	
	DoodleBikeMain.background = R.drawable.main;		             
	SimulationView.BGX = (float) 0;			     	               	 
	SimulationView.BGY = (float) 0; 
	SimulationView.BGRateX = (float) .2;			     			     
	SimulationView.BGRateY = (float) 0; 
	
	SimulationView.forGroundBottom = false;
	DoodleBikeMain.forgroundBottom = 0;		         
	SimulationView.FGBX = (float) 0;			     		     	 
	SimulationView.FGBY = (float) 0;
	SimulationView.FGBRateX = (float) .4;			     			 
	SimulationView.FGBRateY = (float) .1; 
	
	SimulationView.forGroundTop = false;
	DoodleBikeMain.forgroundTop = R.drawable.cpaper;		        
	SimulationView.FGTX = (float) 0;			     			     
	SimulationView.FGTY = (float) 0;
	SimulationView.FGTRateX = (float) 0;			     			
	SimulationView.FGTRateY = (float) 0; 
}
	// -------- Levels --------//
	
}
