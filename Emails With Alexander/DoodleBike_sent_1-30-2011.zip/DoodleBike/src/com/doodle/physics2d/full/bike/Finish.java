package com.doodle.physics2d.full.bike;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import at.emini.physics2D.Body;
import at.emini.physics2D.Motor;
import android.view.View.OnClickListener;

import com.doodle.physics2d.full.bike.DoodleBikeMain;
import com.doodle.physics2d.graphics.GraphicsWorld;
import com.doodle.physics2d.graphics.UserImages;
import com.doodle.physics2d.full.bike.R;

import android.content.Intent;
import android.graphics.Typeface;
import android.hardware.SensorManager;

public class Finish extends Activity {
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);     
        
        setRequestedOrientation(0);
        setContentView(R.layout.finish);
      
        Typeface tf = Typeface.createFromAsset(getAssets(),
        "fonts/Brushed.ttf");
        
     
        TextView tv   = (TextView) findViewById(R.id.TextView01);
        tv.setTypeface(tf);
        final Button MarketButton = (Button) findViewById(R.id.Rate);
        MarketButton.setTypeface(tf);
     
        

        MarketButton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) { 			
				 Intent Market = new Intent(Intent.ACTION_VIEW,Uri.parse("market://details?id=com.doodle.physics2d.full.bike"));
				 startActivity(Market);
			} 
		});	      
		
			

        
		
        
        
        
		
   }     
    
    protected void onResume() 
    {   	
        super.onResume();
    }  
    
}
	
	
	
	
	
