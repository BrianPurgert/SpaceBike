// Author Brian A. Purgert
// Physics by Alexander Adensamer

package com.doodle.physics2d.graphics;

import java.util.Random;

import com.doodle.physics2d.lite.bike.DoodleBikeMain;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LightingColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.hardware.SensorListener;
import android.hardware.SensorManager;
import at.emini.physics2D.Body;
import at.emini.physics2D.Constraint;
import at.emini.physics2D.Event;
import at.emini.physics2D.Landscape;
import at.emini.physics2D.Motor;
import at.emini.physics2D.ParticleEmitter;
import at.emini.physics2D.Shape;
import at.emini.physics2D.Spring;
import at.emini.physics2D.UserData;
import at.emini.physics2D.World;
import at.emini.physics2D.util.FXUtil;
import at.emini.physics2D.util.FXVector;

public class GraphicsWorld extends World implements SensorListener
{
	public static boolean frontwheel; // Variable to load the motor for the front wheel
	DoodleBikeMain game;
	/**
     * Flag whether to draw the landscape of the bodies. <br>
     * This can be set to false if the background drawing handles the landscape.
     * See @link {@link JumperCanvas}. 
     */
	private boolean drawLandscape = false;

    private Body bodyToRemove = null;
    
	//helper points for spring drawing
    private FXVector p1 = new FXVector();
    private FXVector p2 = new FXVector();
        
    //the random number generator for the jitter functionality
    private Random random = new Random();

    private int mBikeMotorForceFX = -2900 * FXUtil.ONE_FX;
    private long mBikeSpeedFactorFX = -4300 * FXUtil.ONE_FX;
    public Motor mBikeMotor;
    public Event crash;
   
   
    //--------------wheels--------------//
    private int mWheelMotorForceFX = 200000 * FXUtil.ONE_FX;
    //  private int mWheelMotorForceFX = 90000 * FXUtil.ONE_FX;
    // private int mWheelMotorForceFX = 50000 * FXUtil.ONE_FX;
    private long mWheelSpeedFactorFX = 10000 * FXUtil.ONE_FX;
    
    public static int landscapeWidth;
    public static int lColor1;
    public static int lColor2;
    public static int lColor3;
    
    private Motor mWheelMotor1;
    private Motor mWheelMotor2;
    
    public static final Paint renderBodies = new Paint();
    public static final Paint renderStaticBodies = new Paint();
    public static final Paint renderSpring = new Paint();
    public static final Paint renderLandscape = new Paint();
    public static final Paint renderParticles = new Paint();
    static
    {
        
        renderBodies.setAntiAlias(true);
        renderBodies.setColor    (Color.rgb(32,178,170));
        renderBodies.setTextSize (20.0f		); //Added by Alen Brkicic on 27.02.2010
       // renderBodies.setDensity(1);
        
        renderStaticBodies.setAntiAlias(true);
        renderStaticBodies.setColorFilter(new LightingColorFilter(0xffa0a0a0, 0xff000000));
        
        renderSpring.setColor(Color.rgb(255,140,0));        
        
    //    renderLandscape.setColor(Color.rgb(161,29,33));
    //    renderLandscape.setStrokeWidth(5);     
      //  renderLandscape.setStyle(Style.STROKE);
        
        renderParticles.setColor(0xFFA0A0A0);        
    }
    
  //  private int baseGravityFX = 150 * FXUtil.ONE_FX;
  //  private FXVector newGravity = new FXVector(0, baseGravityFX);
    
    /**
     * Default constructor
     */
    public GraphicsWorld()
    {
        super();
    }
    
    public GraphicsWorld(int baseGravityFX)
    {
        super();
    //    this.baseGravityFX = baseGravityFX;
    }

    /**
     * Copy Constructor
     * @param world the world to copy
     */
    public GraphicsWorld(World world)
    {        
        super(world);
     
    }
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
    //                    Initiate Motors                        //
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
    public void initMotors()
    {
        int bodyCount = getBodyCount();
        Body[] bodies = getBodies();
        for( int i = 0; i < bodyCount; i++)         
        {
            UserImages userShapedata = (UserImages) (bodies[i].shape().getUserData());
            if(userShapedata == null) continue;
            if ( userShapedata.type == UserImages.M_TYPE_BIKE )
            {                    
                mBikeMotor = new Motor(bodies[i], 0, mBikeMotorForceFX);
                addConstraint(mBikeMotor);
                mBikeMotor.setParameter(0, 0, true, false);
            //    crash = new Event(bodies[i],);
                
            }
            else if ( userShapedata.type == UserImages.M_TYPE_WHEEL )
            {       
                
                Motor wheelMotor = new Motor(bodies[i], 0, mWheelMotorForceFX);
               // addConstraint(wheelMotor);
                //wheelMotor.setParameter(mWheelSpeedFactorFX, 0, true, false);
                
                if (mWheelMotor1 == null) 
                {
                    mWheelMotor1 = wheelMotor;
                }
                else if (mWheelMotor2 == null)
                {
                    mWheelMotor2 = wheelMotor;
                }
            }
            
        }
        
             
    }
    
    /**
     * Method to displace all bodies within the world by a small random amount 
     * @param maxAmount the max amount to move the bodies
     */
    public void translate(FXVector translation)
    {
        int bodyCount = getBodyCount();
        Body[] bodies = getBodies();
        for( int i = 0; i < bodyCount; i++)
        {
            bodies[i].positionFX().add( translation);
        }
    }


    /**
     * Render the world to the graphics object
     * @param graphics the graphics object
     */
    public void draw(Canvas canvas, int xTranslate, int yTranslate)
    {           
        canvas.translate(-xTranslate, -yTranslate);
        
        //draw the landscape by walking over all segments and drawing the line
        if ( drawLandscape)
        {
            Landscape landscape = getLandscape();
            FXVector startPoint, endPoint;
            for( int i = 0; i < landscape.segmentCount(); i++)
            {        
                startPoint = landscape.startPoint(i);
                endPoint = landscape.endPoint(i);
                canvas.drawLine(startPoint.xFX >> FXUtil.DECIMAL, 
                                startPoint.yFX >> FXUtil.DECIMAL,
                                endPoint.xFX >> FXUtil.DECIMAL, 
                                endPoint.yFX >> FXUtil.DECIMAL,
                                renderLandscape);                
            }
        }
        
        
        //draw the springs
        //by walking over all constraint and checking for springs
        //the springs are drawn as a line from anchor one to anchor two  
        int constraintCount = getConstraintCount();
        Constraint[] constraints = getConstraints();
        
        for(int i = 0; i < constraintCount; i++)
        {    
            if (constraints[i] instanceof Spring)
            {
                Spring spring = (Spring) constraints[i];
                spring.getPoint1(p1);
                spring.getPoint2(p2);
                canvas.drawLine(p1.xFX >> FXUtil.DECIMAL, p1.yFX >> FXUtil.DECIMAL, 
                                p2.xFX >> FXUtil.DECIMAL, p2.yFX >> FXUtil.DECIMAL, 
                                renderSpring);                
            }
        }
        
        

        for( int i = 0; i < getParticleEmitters().size(); i++)
        {            
            ParticleEmitter emitter = (ParticleEmitter) getParticleEmitters().elementAt(i);
            
            int[] xFX = emitter.getXPosFX();
            int[] yFX = emitter.getYPosFX();
            short[] life = emitter.getLifeTimes();
            int size = xFX.length;                
            for( int j = 0; j < size; j++)
            {
                if (life[j] > 0)
                {              
                    canvas.drawCircle(xFX[j]>>FXUtil.DECIMAL, yFX[j]>>FXUtil.DECIMAL, 2, renderParticles);
                    //canvas.drawBitmap(particleImage, xFX[j]>>FXUtil.DECIMAL, yFX[j]>>FXUtil.DECIMAL, renderParticles);                    
                }
            }            
        }
        
        /*
         * Draw the bodies
         * by walking over all bodies that are currently in
         * simulation scope (see World#setSimulationArea())
         * so we walk from getBodyStartIndex() to getBodyEndIndex()
         */        
        Body[] bodies = getBodies();
        int bodyEndIndex = getBodyEndIndex();        
        for(int i = getBodyStartIndex(); i < bodyEndIndex; i++)
        {   
        	drawBody( canvas, bodies[i], xTranslate, yTranslate);
        }
        
        canvas.translate(xTranslate, yTranslate);
    }
   
    
    /**
     * Render a single body to the graphics object. <br>
     * Checks the ShapeSet if an image exists.
     * Checks if the shape is colored and supplies a non-default color (used in @link {@link BilliardSimulationCanvas}
     * Checks whether to draw the contour and/or the fill 
     * @param graphics  the graphics object 
     * @param body the body to draw
     */
    private Matrix matrix = new Matrix();    
    public final void drawBody(Canvas canvas, Body body, int xTranslate, int yTranslate)
    {   
        //check whether body is on screen
        if ( body.getAABBMinXFX() > (canvas.getWidth() + xTranslate ) * FXUtil.ONE_FX || 
             body.getAABBMaxXFX() < xTranslate * FXUtil.ONE_FX ||
             body.getAABBMinYFX() > (canvas.getHeight() + yTranslate ) * FXUtil.ONE_FX || 
             body.getAABBMaxYFX() < yTranslate * FXUtil.ONE_FX )
        {
            return;
        }
        
        Shape shape = body.shape();
        
        //Bitmap image = ((GraphicsShapeSet) shapeSet).getImage(shape);  //check if an image is registered for the body
        Bitmap image = null;
        
        UserData userdata = shape.getUserData();
        if (userdata != null && userdata instanceof UserImages)
        {
            image = ((UserImages) userdata).getImage();
        }
        
        if (image != null)
        { 
            //draw the image if one was found
            FXVector position = body.positionFX();
            matrix.reset();
            matrix.postRotate( ((float) body.rotation2FX() * 360f / FXUtil.TWO_PI_2FX),
                    image.getWidth() / 2, image.getHeight() / 2);
            matrix.postTranslate(
                    (position.xFX >> FXUtil.DECIMAL) - image.getWidth() / 2,
                    (position.yFX >> FXUtil.DECIMAL) - image.getHeight() / 2);
            Paint paint = renderBodies;
            if(! body.isDynamic())
            {
                paint = renderStaticBodies;
            }
            canvas.drawBitmap(image, matrix, paint);
        }
        else
        {
            FXVector[] positions = body.getVertices();
            if (positions.length == 1)
            {
                canvas.drawCircle(
                        body.positionFX().xFX >> FXUtil.DECIMAL, 
                        body.positionFX().yFX >> FXUtil.DECIMAL, 
                        body.shape().getBoundingRadiusFX() >> FXUtil.DECIMAL, 
                        renderBodies);
            }
            else
            {
                for( int j = positions.length - 1, i = 0; i < positions.length; j = i,i++)
                {           
                    canvas.drawLine(
                            positions[i].xFX >> FXUtil.DECIMAL, 
                            positions[i].yFX >> FXUtil.DECIMAL, 
                            positions[j].xFX >> FXUtil.DECIMAL, 
                            positions[j].yFX >> FXUtil.DECIMAL, 
                            renderBodies);
                }    
            }
        }
    }
   
    public void tick()
    {
 //       setGravity(newGravity);
        
        super.tick();
        
        if (bodyToRemove != null)
        {
            removeBody(bodyToRemove);    
            bodyToRemove = null;
        }
    }
    
    public void scheduleBodyRemove(Body b)
    {
    //	bodyToRemove = b;
    	game.turnOnMenu();
    }
        
    //Setter and Getters
    
    public boolean isDrawLandscape()
    {
        return drawLandscape;
    }

    public void setDrawLandscape(boolean drawLandscape)
    {
        this.drawLandscape = drawLandscape;
    }
   
    
    
    public void setNewGravity(FXVector newGravity)
    {
        //check for perfectly balanced phone
        if (newGravity.xFX == 0 && newGravity.yFX == 0)
        {
            return;
        }
        
        newGravity.normalize();
        
     //   newGravity.multFX(baseGravityFX);
  //      this.newGravity = newGravity;
    }
    
    public void onAccuracyChanged(int sensor, int accuracy)
    {        
    }
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
  //               Add Bike and create the motor attached to it                  //
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//  
   
    
/*    
    private Body[] mBikeBody;
    private Motor mBikeMotor;
    private static final int mSpeedFactor = FXUtil.ONE_FX * 50;

    public void addRagdoll(World ragDollWorld)
    {
        Body[] bodyMapping = addWorld(bikeWorld);
        
        int bodyCount = ragDollWorld.getBodyCount();
        Body ragdollBodies[] = ragDollWorld.getBodies();
        mBikeBody = new Body[ragDollWorld.getBodyCount()];
        int idx = 0;
        for( int i = 0; i < bodyCount; i++)
        {
        	mBikeBody[idx] = bodyMapping[ragdollBodies[i].getId()];
           // BodyUserData bodyData = (BodyUserData)
        	 UserImages userShapedata = (UserImages)
            mBikeBody[idx].getUserData();
            if (userShapedata != null &&  userShapedata.type == 0())
            {
            	mBikeMotor = new Motor(mBikeBody[idx], 0, 0, mMotorForce);
                addConstraint(mBikeMotor);
            }
            idx++;
        }
    }
    */
	
    //++++++++++++++++++++++++++++++++++++++++++++++++++++
    float xvalue;
	float yvalue;
	float zvalue;
	int sensitivity;
    public void onSensorChanged(int sensor, float[] values)
    {
    
    xvalue = values[0]; 
    yvalue = values[1] * sensitivity;
    zvalue = values[2] * sensitivity;
    
        switch(sensor) 
        {        
      case SensorManager.SENSOR_ACCELEROMETER:
    	      	   
    	 // setBikeTurningPower(0);
	    //	setBikeTurningSpeed(values[0]);
    	    
    	    int max = 5;
    	   
    	   if (xvalue < max && xvalue > - max ){
    	        	    	setBikeTurningPower(xvalue);
    	        	    	setBikeTurningSpeed(xvalue);
    	    } 
    	    if (xvalue > max){
    	    	setBikeTurningPower(max);
    	    	setBikeTurningSpeed(max);
    	    }
    	    if (xvalue < -max){
    	    	setBikeTurningPower(-max);
    	    	setBikeTurningSpeed(-max);
    	    }
    	    
            break;
        default: 
            break;
        }
    }
    
    public void setBikeTurningPower(float value)
    {   
        if (mBikeMotor != null)
        {
            int maxForceFX = (int) (value * mBikeMotorForceFX);
            
            mBikeMotor.setMaxForceFX(maxForceFX);
            
            
        }
    }

    public void setBikeTurningSpeed(float value)
    {   
        if (mBikeMotor != null)
        {
            int targetAFX = (int) (value * mBikeSpeedFactorFX);
            mBikeMotor.setParameter(targetAFX, 0, true, false);
        }
    }

    public void setWheelSpeed(float value)
    {   
        if (mWheelMotor1 != null && mWheelMotor2 != null)
        {
           
            
            int targetAFX = -(int) (value * mWheelSpeedFactorFX);
            mWheelMotor1.setParameter(targetAFX, 0, true, false);
            mWheelMotor2.setParameter(targetAFX, 0, true, false);
        }
    }
   
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
//                       Wheel On/Off                        //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//    
    
    
    public void putmotor(){
    	if(frontwheel == true){
    	addConstraint(mWheelMotor1);     // Front Wheel
    	}
    	addConstraint(mWheelMotor2);     // Rear Wheel
    	
    }
    public void takemotor(){
    	removeConstraint(mWheelMotor1);    // Front Wheel
    	removeConstraint(mWheelMotor2);   // Rear Wheel
    }	
    	
    	
    }
    
    
    
    
    

