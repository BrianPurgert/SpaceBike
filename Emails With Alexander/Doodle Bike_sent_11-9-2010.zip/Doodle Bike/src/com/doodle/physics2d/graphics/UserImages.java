/*
 * Emini Physics Engine Demo source 
 * by Alexander Adensamer
 * 
 * Copyright (c) 2010, Emini Physics - Alexander Adensamer
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or 
 * without modification, are permitted provided that the following 
 * conditions are met:
 * 
 *  * Redistributions of source code must retain the above 
 *    copyright notice, this list of conditions and the 
 *    following disclaimer.
 *  * Redistributions in binary form must reproduce the above 
 *    copyright notice, this list of conditions and the following 
 *    disclaimer in the documentation and/or other materials provided 
 *    with the distribution.
 *  * Neither the name of the Emini Physics nor the names of 
 *    its contributors may be used to endorse or promote products 
 *    derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND 
 * CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, 
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE 
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS 
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, 
 * OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
 * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT 
 * OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY 
 * OF SUCH DAMAGE.
 */

package com.doodle.physics2d.graphics;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import at.emini.physics2D.Body;
import at.emini.physics2D.UserData;

import com.doodle.physics2d.lite.bike.R;
import com.doodle.physics2d.lite.bike.R.drawable;

public class UserImages implements UserData {

	 
    public static final String[] Identifiers = {"bike","wheel","motobike","motowheel","quad","quadwheel" };
    public static final int[] BitmapIds = 
    {
    	R.drawable.bike,
        R.drawable.bikewheel,
        
        R.drawable.motobike,
        R.drawable.motowheel,
        
        R.drawable.quadbike,
        R.drawable.quadwheel,
        
        
        
        
     /*   R.drawable.eraser,
        R.drawable.crayon,
        R.drawable.pencil,
        R.drawable.ruler,
        R.drawable.button,   */
    };
    
    public static Bitmap[] bitmaps = new Bitmap[BitmapIds.length];
  //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      public int type = -1;
	
      public static int M_TYPE_BIKE; 
      public static int M_TYPE_WHEEL; 
      
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	public UserImages()
	{
	}
	 
	
	private UserImages(int type)
	{
		this.type = type;
	}
	
	public int type()
	{
	    return type;	    
	}
	
	public Bitmap getImage()
	{
	    return bitmaps[type];
	}
	
	public static void initBitmaps(Resources res)
	{
	    for( int i = 0; i < BitmapIds.length; i++)
	    {
	        bitmaps[i] = BitmapFactory.decodeResource(res, BitmapIds[i]);
	    }
	}
	
	
	@Override
	public UserData copy() {
		return new UserImages(type);
	}

	@Override
	public UserData createNewUserData(String data, int type)
	{
		
		for( int i = 0; i < Identifiers.length; i++)
		{
		    if (data.equals(Identifiers[i]))
		    {
		        return new UserImages(i);
		    }
		}
		
		return null;
	}

}
