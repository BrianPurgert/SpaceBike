/*
 * Doodle Bike source 
 * by Brian Purgert
 * 
 *  * Copyright (c) 2010, DoodleBike - Brian Purgert
 * All rights reserved.
 * 
 * 
 * 
 * Emini Physics engine 
 * by Alexander Adensamer
 * Copyright (c) 2010, Emini Physics - Alexander Adensamer
 * All rights reserved.
 * 

 */

package com.doodle.physics2d.lite.bike;

import java.util.HashMap;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import at.emini.physics2D.Body;
import at.emini.physics2D.Event;
import at.emini.physics2D.Motor;
import at.emini.physics2D.PhysicsEventListener;
import at.emini.physics2D.Shape;
import at.emini.physics2D.World;
import at.emini.physics2D.Constraint;
import at.emini.physics2D.util.FXUtil;
import at.emini.physics2D.util.PhysicsFileReader;
import com.doodle.physics2d.lite.bike.SoundManager;
import com.doodle.physics2d.graphics.GraphicsWorld;
import com.doodle.physics2d.graphics.SimulationView;
import com.doodle.physics2d.graphics.UserImages;
import com.doodle.physics2d.graphics.SimulationView;
import com.doodle.physics2d.graphics.UserImages;
import com.doodle.physics2d.lite.bike.Level;
import com.doodle.physics2d.lite.bike.R;

public class DoodleBikeMain extends Activity 
{
		
	private SoundManager mSoundManager;
   
	private Handler handler;    
    private GraphicsWorld world;
    public  World bike;
   
    private SimulationView simulationView;
    private SensorManager mSensorManager;    

//-------Loading Level Variables-----// 
    public static int background;
    public static boolean Xaxis;
    public static boolean Drawlandscape;
    public static int pickedWorld;
   
    public static int pickedBike;
    public static int WheelSpeed;
//------Turns on Content Views----//
    public static int controlsvisibility;
    public static int TheGameMenu;
	
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
    	  		
        super.onCreate(savedInstanceState);
        setRequestedOrientation(0); 

//+++++++++++++++++++++++++++++++++++++++++++++++++//   
//                Set up FX sounds                 //       
//+++++++++++++++++++++++++++++++++++++++++++++++++//     
        mSoundManager = new SoundManager();
        mSoundManager.initSounds(getBaseContext());
        mSoundManager.addSound(1, R.raw.bikestart);
        mSoundManager.addSound(2, R.raw.bikestop);
        mSoundManager.addSound(3, R.raw.bikeidle);
        
        
        
        
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        handler = new Handler();       

        UserImages.initBitmaps(getResources());
        createWorld();
        
        simulationView = new GameEvents(this, world);
        simulationView.setKeepScreenOn(true);        

        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//  
        //                      Set Up Rotational Motors                             //
        //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//

      
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
//                  Load the bike and add it to the level                    //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//        
        PhysicsFileReader readerTrain = new PhysicsFileReader(getResources().openRawResource(pickedBike));
        GraphicsWorld bike = new GraphicsWorld( World.loadWorld(readerTrain, new UserImages()) );
        world.addWorld(bike);

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
//                Find the body for centering and Load motors                //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//

        int bodyCount    = world.getBodyCount();
        Body[] bodies = world.getBodies();
        for( int i = 0; i < bodyCount; i++)        	
        {        	
        	UserImages userShapedata = (UserImages) (bodies[i].shape().getUserData());
            if(userShapedata == null) continue;
            if ( userShapedata.type == UserImages.M_TYPE_BIKE )
            {
                simulationView.setViewBody(bodies[i],true,Xaxis); 
                
            }
        }
                    
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//  
//                 Start Game and load Content View                          //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//   

        setContentView(R.layout.game);   
        RelativeLayout gamelayout = (RelativeLayout) findViewById(R.id.GameLayout);       
        gamelayout.addView(simulationView, 0);
           
        
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//       
//               Set Background as RGB 565 so it saves memory                //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//  

        BitmapFactory.Options options = new BitmapFactory.Options();    
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        simulationView.setBackground(BitmapFactory.decodeResource(getResources(), background, options)); //Background 
      
        world.initMotors();
        world.putmotor();
        
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//       
//             Load In games menus/End level and Tutorial layout             //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//         
        
        final RelativeLayout controls = (RelativeLayout) findViewById(R.id.RelativeLayout02);
        controls.setVisibility(controlsvisibility);
                
    //    final RelativeLayout gamemenu = (RelativeLayout) findViewById(R.id.RelativeLayout01);
     //    gamemenu.setVisibility(TheGameMenu); 
      //   gamemenu.setVisibility(View.VISIBLE); // When end level event starts      
		
         
         
        
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//  
//                  Initiate Forward and Backward buttons                    //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//        	    
//                    Forward                   //
//----------------------------------------------//
        final Button forward = (Button) findViewById(R.id.forward);
		 forward.setOnTouchListener(new View.OnTouchListener() {	  			
			public boolean onTouch(View v, MotionEvent down) {								
				world.putmotor();
				world.setWheelSpeed(WheelSpeed);			
			//	mSoundManager.playLoopedSound(2);  // Motor sound				
				return false;	
			} 
	       	 });
		//----------------------------------------------//        
        forward.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { 
            	world.takemotor();
            	world.setWheelSpeed(0);
           // 	mSoundManager.stopLoopedSound(2); // turns off motor sound        	
           } 
             }); 
        //---------------------------------------------//
        //                   Reverse                   //
        //---------------------------------------------//
        final Button reverse = (Button) findViewById(R.id.reverse);
		 reverse.setOnTouchListener(new View.OnTouchListener() {	  			
			public boolean onTouch(View v, MotionEvent down) {				
				world.putmotor();
				world.setWheelSpeed(-2);	
				return false;	
			} 
	       	 });
        //----------------------------------------------//		 
        reverse.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) { 
            	world.takemotor();
                world.setWheelSpeed(0);
                
            } 
        });    
    } 
       //----------------------------------------------//

   
  
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//       
//  I tried to make something that starts a count down when the game starts  //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//     
  /*  
   public void gameStart(){
	   final View number = (View) findViewById(R.id.View01);
	   final RelativeLayout starup = (RelativeLayout) findViewById(R.id.RelativeLayout03);
	   starup.setVisibility(View.VISIBLE);
	   starup.setBackgroundResource(R.drawable.redover);
	   number.setBackgroundResource(R.drawable.t);
	   wait (1000);
	   number.setBackgroundResource(R.drawable.two);
	   wait (1000);
	   number.setBackgroundResource(R.drawable.one);
	   wait (1000);
	   starup.setBackgroundResource(R.drawable.greenover);
	   number.setBackgroundResource(R.drawable.go);
	   wait (10000);
	   starup.setVisibility(View.GONE);
   }
    
   public static void wait (int n){
       long t0,t1;
       t0=System.currentTimeMillis();
       do{
           t1=System.currentTimeMillis();
       }
       while (t1-t0<1000);
}
   */
    
    public void turnOnMenu(){
     	TheGameMenu = View.VISIBLE;
     }   
    
//--------------------//    
	@Override
    protected void onPause() 
    {


        super.onPause();
        handler.removeCallbacks(update);
        mSensorManager.unregisterListener(world);
    }
//--------------------// 
    @Override
    protected void onResume() 
    {
        super.onResume();
        handler.post(update);

        if (world != null)
        {
            mSensorManager.registerListener(world, 
                    SensorManager.SENSOR_ACCELEROMETER,
                    SensorManager.SENSOR_DELAY_GAME);
        }

    }
//--------------------// 
    public GraphicsWorld createWorld()
    {                
        PhysicsFileReader reader = new PhysicsFileReader(getResources().openRawResource(pickedWorld));
        world = new GraphicsWorld( World.loadWorld(reader, new UserImages()) );

        world.setDrawLandscape(Drawlandscape);
        mSensorManager.registerListener(world, 
                SensorManager.SENSOR_ACCELEROMETER,
                SensorManager.SENSOR_DELAY_GAME);

        return world;
    }    
//--------------------//    
    private Runnable update = new Runnable() 
    {
        public void run() 
        {            
            long start = System.currentTimeMillis();
            simulationView.tickWorld();
            long end = System.currentTimeMillis();
            handler.postDelayed(update, (long) Math.max( 50 - (end - start), 0));
        }

    };
//--------------------//      
}