package com.doodle.physics2d.lite.bike;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageButton;

public class Menu extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
      
        setContentView(R.layout.main);
        
        ImageButton play   = (ImageButton)findViewById(R.id.play);
        ImageButton info   = (ImageButton) findViewById(R.id.info);
        ImageButton option = (ImageButton) findViewById(R.id.options); 

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
//                         Set up Menus                            //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//   
        play.setOnClickListener(new OnClickListener() {
        	public void onClick(View v) {
        		
        		Intent BikeIntent = new Intent(Menu.this,Level.class);
        		startActivity(BikeIntent);
        		
        	}
        });                 
//--------------------------------------------------------//         
        info.setOnClickListener(new OnClickListener() {  	
        	public void onClick(View v) {
        		
        		Intent InfoIntent = new Intent(Menu.this,Info.class);
        		startActivity(InfoIntent);
        		
        	}
        });        
//--------------------------------------------------------//        
        option.setOnClickListener(new OnClickListener() {	
        	public void onClick(View v) {
        		
        		Intent OptionIntent = new Intent(Menu.this,Options.class);
        		startActivity(OptionIntent);
        		
        	}
        });     
//--------------------------------------------------------//      
    }
}