package com.doodle.physics2d.lite.bike;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import at.emini.physics2D.Body;
import at.emini.physics2D.Motor;
import android.view.View.OnClickListener;
import com.doodle.physics2d.graphics.GraphicsWorld;
import com.doodle.physics2d.graphics.UserImages;
import com.doodle.physics2d.lite.bike.DoodleBikeMain;
import com.doodle.physics2d.lite.bike.R;

import android.content.Intent;

public class Bike extends Activity {
	   public static int bv1;
       public static int bv2;
       public static int bv3;
       public static int locked1;
       public static int locked2;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        

        
        setRequestedOrientation(1);
        setContentView(R.layout.bike);
       
      
        
        final ImageButton bike1 = (ImageButton) findViewById(R.id.bike1);
        final ImageButton bike2 = (ImageButton) findViewById(R.id.bike2);
        final ImageButton bike3 = (ImageButton) findViewById(R.id.bike3);
    //    final ImageButton bike4 = (ImageButton) findViewById(R.id.bike4);
        final ImageButton back = (ImageButton) findViewById(R.id.back);
        
        bike2.setBackgroundResource(locked1);
        bike3.setBackgroundResource(locked2);
        
        
    //    bike1.setVisibility(bv1);
    //    bike2.setVisibility(bv2);
    //    bike3.setVisibility(bv3);
        
        
		bike1.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) { 
				DoodleBikeMain.pickedBike = R.raw.bike; 
				DoodleBikeMain.WheelSpeed = 5;
				UserImages.M_TYPE_BIKE = 0; 
				UserImages.M_TYPE_WHEEL = 1;
				
				GraphicsWorld.frontwheel = false;
				
				Intent levelIntent = new Intent(Bike.this,DoodleBikeMain.class);
        		startActivity(levelIntent); 
			} 
			
		});
				
			bike2.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) { 
					DoodleBikeMain.pickedBike = R.raw.moto;
					DoodleBikeMain.WheelSpeed = 9;
					UserImages.M_TYPE_BIKE = 2; 
					UserImages.M_TYPE_WHEEL = 3;
					GraphicsWorld.frontwheel = false;
					Intent levelIntent = new Intent(Bike.this,DoodleBikeMain.class);
	        		startActivity(levelIntent); 
				
				}
				
			}); 
							
			bike3.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) { 
					DoodleBikeMain.pickedBike = R.raw.quad; 
					DoodleBikeMain.WheelSpeed = 8;
					UserImages.M_TYPE_BIKE = 4; 
					UserImages.M_TYPE_WHEEL = 5;
					GraphicsWorld.frontwheel = true;
					Intent levelIntent = new Intent(Bike.this,DoodleBikeMain.class);
	        		startActivity(levelIntent); 
				}
			}); 
			
			/*
			bike4.setOnClickListener(new View.OnClickListener() {
				public void onClick(View v) { 
					PhysEngineAndroidSample.pickedBike = R.raw.flip;
					PhysEngineAndroidSample.WheelSpeed = 10;
					UserImages.M_TYPE_BIKE = 6; 
					UserImages.M_TYPE_WHEEL = 7;
					GraphicsWorld.frontwheel = true;
					Intent levelIntent = new Intent(Bike.this,Level.class);
	        		startActivity(levelIntent); 
				}
			});
        */
        
		back.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) { 
				finish(); 
			} 	
		});    
        
        
        
		
   }     
}
	
	
	
	
	
	


