
package com.doodle.physics2d.lite.bike;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.widget.RelativeLayout;
import at.emini.physics2D.Body;
import at.emini.physics2D.Event;
import at.emini.physics2D.PhysicsEventListener;
import at.emini.physics2D.World;

import com.doodle.physics2d.graphics.GraphicsWorld;
import com.doodle.physics2d.graphics.SimulationView;

public class GameEvents extends SimulationView implements PhysicsEventListener
{
	DoodleBikeMain game;
    public GameEvents(Context context, GraphicsWorld world)
    {
        super(context, world);
        world.setPhysicsEventListener(this);
    }
     
//I'm trying to have 3 events
    // one that triggers when the the landscape / static objects touches the top of the viewbody(tip over) this opens a menu that lets you try again
    // one that triggers when the viewbody is inside Area event 1. (when the player falls off of the landscape)this opens a menu that lets you try again
    // one that triggers when the viewbody is inside Area event 0(finish line) this then opens a menu that lets you go on to the next level
   
    
    
    
    public void eventTriggered(Event event, Object object)
    {
  
    	final RelativeLayout gamemenu = (RelativeLayout) findViewById(R.id.RelativeLayout01);
            gamemenu.setVisibility(View.VISIBLE);  		
        
    }
}
