package com.doodle.physics2d.lite.bike;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.view.View.OnClickListener;
import com.doodle.physics2d.graphics.GraphicsWorld;
import com.doodle.physics2d.graphics.SimulationView;    
import com.doodle.physics2d.lite.bike.DoodleBikeMain;
import com.doodle.physics2d.lite.bike.R;
import com.doodle.physics2d.lite.bike.Bike;

public class Level extends Activity {

	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       
        setRequestedOrientation(1);
        setContentView(R.layout.level2);
        
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//   
//                              Load Buttons                               //
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//
        final ImageButton level1 = (ImageButton) findViewById(R.id.level1);
        final ImageButton level2 = (ImageButton) findViewById(R.id.level2);
        final ImageButton level3 = (ImageButton) findViewById(R.id.level3);
        final ImageButton level4 = (ImageButton) findViewById(R.id.level4);
        final ImageButton back   = (ImageButton) findViewById(R.id.back);
       
		level1.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) { 
				
				DoodleBikeMain.background = R.drawable.back1;		 // background image						
				DoodleBikeMain.Xaxis = false;                       // If the camera goes up or down
				DoodleBikeMain.Drawlandscape = false;               // Draw Landscape 
				DoodleBikeMain.pickedWorld = R.raw.world;			 // World to load	     
				DoodleBikeMain.controlsvisibility = View.GONE;   // Tutorial Overlay
			//	PhysEngineAndroidSample.TheGameMenu = View.GONE;          // Game Menu
				
				SimulationView.BGRate = (float) 1;			     			 // The rate at which the background moves
			       
			     Bike.locked1 = R.drawable.motobuttonlocked;        // Sets Bike picture to locked
			     Bike.locked2 = R.drawable.quadbuttonlocked;	    // Sets Bike picture to locked	     
			     
			     Intent PlayIntent = new Intent(Level.this,Bike.class);     
	        		startActivity(PlayIntent);	  
			} 
		});
			
			
			
			 
				level2.setOnClickListener(new View.OnClickListener() {
					public void onClick(View v) { 

						DoodleBikeMain.background = R.drawable.back2;								
						DoodleBikeMain.Xaxis = true;
						DoodleBikeMain.Drawlandscape = true;
						DoodleBikeMain.pickedWorld = R.raw.world2; 
						DoodleBikeMain.controlsvisibility = View.GONE;
					//	PhysEngineAndroidSample.TheGameMenu = View.GONE;
						
						GraphicsWorld.renderLandscape.setColor(Color.rgb(161,29,33));  // The Color of the landscape
						GraphicsWorld.renderLandscape.setStrokeWidth(5);               // The width of the landscape
						  
					     SimulationView.BGRate = (float) .2;  
					     	     
					     Bike.locked1 = R.drawable.motobutton;
					     Bike.locked2 = R.drawable.quadbuttonlocked;
					     
					     Intent PlayIntent = new Intent(Level.this,Bike.class);
			        		startActivity(PlayIntent);
					}
				});
				
					
						level3.setOnClickListener(new View.OnClickListener() {
							public void onClick(View v) { 
								
								DoodleBikeMain.background = R.drawable.cpaper;								
								DoodleBikeMain.Xaxis = true;
								DoodleBikeMain.Drawlandscape = true;
								DoodleBikeMain.pickedWorld = R.raw.world4;
								DoodleBikeMain.controlsvisibility = View.GONE;
						//		PhysEngineAndroidSample.TheGameMenu = View.GONE;
								
								GraphicsWorld.renderLandscape.setColor(Color.rgb(0,0,205));
								GraphicsWorld.renderLandscape.setStrokeWidth(4); 
								     
							     SimulationView.BGRate = (float) .3;  
							       
							     Bike.locked1 = R.drawable.motobutton;
							     Bike.locked2 = R.drawable.quadbuttonlocked;
							     
							     Intent PlayIntent = new Intent(Level.this,Bike.class);
					        		startActivity(PlayIntent); 
							}
						});
							
							
							level4.setOnClickListener(new View.OnClickListener() {
								public void onClick(View v) { 
									
									DoodleBikeMain.background = R.drawable.cpaper;								
									DoodleBikeMain.Xaxis = true;
									DoodleBikeMain.Drawlandscape = true;
									DoodleBikeMain.pickedWorld = R.raw.world5;
									DoodleBikeMain.controlsvisibility = View.GONE;
							//		PhysEngineAndroidSample.TheGameMenu = View.GONE;
									
									GraphicsWorld.renderLandscape.setColor(Color.rgb(0,0,205));
									GraphicsWorld.renderLandscape.setStrokeWidth(4); 
									     
								     SimulationView.BGRate = (float) .3;  // the rate the backround moves
								       
								     Bike.locked1 = R.drawable.motobutton;
								     Bike.locked2 = R.drawable.quadbuttonlocked;
								     
								     Intent PlayIntent = new Intent(Level.this,Bike.class);
						        		startActivity(PlayIntent);  
								}
							});
										
									back.setOnClickListener(new View.OnClickListener() {
										public void onClick(View v) { 
											finish(); 
										} 
									});    
								 
		
	   }  
	
	
	
	}
        
							

